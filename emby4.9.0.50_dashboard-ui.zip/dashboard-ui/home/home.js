define([
    "exports",
    "./../modules/tabbedview/tabbedview.js",
    "./../modules/common/globalize.js",
    "./../modules/maintabsmanager.js",
    "./../modules/emby-elements/emby-scroller/emby-scroller.js",
    "./../modules/emby-elements/emby-button/emby-button.js",
], function (
    _exports,
    _tabbedview,
    _globalize,
    _maintabsmanager,
    _embyScroller,
    _embyButton
) {
    function HomeView(view, params) {
        _tabbedview.default.apply(this, arguments), (this.enableBackMenu = !0);
    }
    Object.defineProperty(_exports, "__esModule", { value: !0 }),
        (_exports.default = void 0),
        Object.assign(HomeView.prototype, _tabbedview.default.prototype),
        (HomeView.prototype.getTabs = function () {
            return [
                { name: _globalize.default.translate("Home"), id: "home" },
                { name: _globalize.default.translate("Favorites"), id: "favorites" },
            ];
        }),
        (HomeView.prototype.getAutoBackdropItemTypes = function () {
            return ["Movie", "Series", "Game", "Book"];
        }),
        (HomeView.prototype.setTitle = function () { }),
        (HomeView.prototype.onPause = function () {
            _tabbedview.default.prototype.onPause.call(this);
        }),
        (HomeView.prototype.destroy = function () {
            _tabbedview.default.prototype.destroy.apply(this, arguments);
        }),
        (HomeView.prototype.loadTabController = function (id) {
            switch (id) {
                case "home":
                    return Emby.importModule("./home/hometab.js");
                case "favorites":
                    return Emby.importModule("./home/favorites.js");
                default:
                    throw new Error("tab not found: " + id);
            }
        }),
        (HomeView.prototype.onWindowInputCommand = function (e) {
            "home" === e.detail.command
                ? (_maintabsmanager.default.selectedTabIndex(0), e.preventDefault())
                : _tabbedview.default.prototype.onWindowInputCommand.apply(
                    this,
                    arguments
                );
        });
    _exports.default = HomeView;
});
