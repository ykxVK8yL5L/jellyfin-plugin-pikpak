define([
  "exports",
  "./../modules/tabbedview/basetab.js",
  "./../modules/common/globalize.js",
  "./../modules/emby-apiclient/connectionmanager.js",
  "./../modules/cardbuilder/cardbuilder.js",
  "./../modules/listview/listview.js",
  "./../modules/approuter.js",
  "./../modules/emby-elements/emby-scroller/emby-scroller.js",
  "./../modules/emby-elements/emby-itemscontainer/emby-itemscontainer.js",
  "./../modules/common/input/api.js",
  "./../modules/emby-apiclient/events.js",
  "./../modules/layoutmanager.js",
  "./../modules/common/usersettings/usersettings.js",
], function (
  _exports,
  _basetab,
  _globalize,
  _connectionmanager,
  _cardbuilder,
  _listview,
  _approuter,
  _embyScroller,
  _embyItemscontainer,
  _api,
  _events,
  _layoutmanager,
  _usersettings
) {
  function FavoritesTab(view, params) {
    _basetab.default.apply(this, arguments),
      (this.view = view),
      (this.params = params),
      (this.apiClient = _connectionmanager.default.currentApiClient()),
      (this.sectionsContainer = view.querySelector(".sections"));
    var i,
      length,
      instance = this,
      elem = this.sectionsContainer,
      apiClient = this.apiClient,
      sections = (function (instance, apiClient) {
        var sections = [
          {
            name: "HeaderFavoriteChannels",
            types: "TvChannel",
            shape: "autooverflow",
            fields: (instance = instance.enableFocusPreview())
              ? []
              : ["Name", "CurrentProgramParentName", "CurrentProgramTime"],
            overlayPlayButton: !0,
            centerText: !0,
            defaultBackground: !0,
            preferThumb: "auto",
            bottomPadding: instance ? "focuspreview" : null,
            programIndicators: !instance,
          },
          {
            name: "HeaderFavoriteShows",
            types: "Series",
            shape: "autooverflow",
            fields: instance ? [] : ["Name", "ProductionYear"],
            overlayPlayButton: !0,
            centerText: !0,
            bottomPadding: instance ? "focuspreview" : null,
          },
          {
            name: "HeaderFavoriteEpisodes",
            types: "Episode",
            shape: "autooverflow",
            preferThumb: !1,
            fields: instance ? [] : ["ParentName", "Name"],
            overlayPlayButton: !0,
            centerText: !0,
            bottomPadding: instance ? "focuspreview" : null,
          },
          {
            name: "HeaderFavoriteMovies",
            types: "Movie",
            shape: "autooverflow",
            fields: instance ? [] : ["Name", "ProductionYear"],
            overlayPlayButton: !0,
            centerText: !0,
            bottomPadding: instance ? "focuspreview" : null,
          },
          {
            name: "HeaderFavoriteMusicVideos",
            types: "MusicVideo",
            shape: "autooverflow",
            fields: instance ? [] : ["Name", "ParentName"],
            overlayPlayButton: !0,
            centerText: !0,
            bottomPadding: instance ? "focuspreview" : null,
          },
          {
            name: "HeaderFavoriteVideos",
            types: "Video",
            shape: "autooverflow",
            preferThumb: !0,
            fields: instance ? [] : ["Name"],
            overlayPlayButton: !0,
            centerText: !0,
            bottomPadding: instance ? "focuspreview" : null,
          },
          {
            name: "HeaderFavoriteCollections",
            types: "BoxSet",
            shape: "autooverflow",
            fields: instance ? [] : ["Name"],
            overlayPlayButton: !0,
            centerText: !0,
            bottomPadding: instance ? "focuspreview" : null,
          },
          {
            name: "HeaderFavoritePlaylists",
            types: "Playlist",
            shape: "autooverflow",
            preferThumb: !1,
            fields: instance ? [] : ["Name"],
            centerText: !0,
            overlayPlayButton: !0,
            bottomPadding: instance ? "focuspreview" : null,
          },
          {
            name: "HeaderFavoriteArtists",
            types: "MusicArtist",
            collectionTypes: "music",
            shape: "autooverflow",
            round: !0,
            preferThumb: !1,
            fields: instance ? [] : ["Name"],
            centerText: !0,
            overlayPlayButton: !0,
            bottomPadding: instance ? "focuspreview" : null,
            cardSizeOffset: "1",
          },
          {
            name: "HeaderFavoriteAlbums",
            types: "MusicAlbum",
            collectionTypes: "music",
            shape: "autooverflow",
            preferThumb: !1,
            fields: instance ? [] : ["Name", "ParentName"],
            centerText: !0,
            overlayPlayButton: !0,
            bottomPadding: instance ? "focuspreview" : null,
          },
          {
            name: "HeaderFavoriteSongs",
            types: "Audio",
            collectionTypes: "music",
            sideFooter: !0,
            shape: "autooverflow",
            preferThumb: !1,
            fields: ["ParentName", "Name"],
            centerText: !1,
            action: "playallfromhere",
            bottomPadding: instance ? "focuspreview" : null,
          },
        ];
        return (
          apiClient.isMinServerVersion("4.9.0.41") &&
            (sections.push({
              name: "HeaderFavoriteAuthors",
              types: "MusicArtist",
              collectionTypes: "audiobooks",
              shape: "autooverflow",
              round: !0,
              preferThumb: !1,
              fields: instance ? [] : ["Name"],
              centerText: !0,
              overlayPlayButton: !0,
              bottomPadding: instance ? "focuspreview" : null,
              cardSizeOffset: "1",
            }),
            sections.push({
              name: "HeaderFavoriteAudioBooks",
              types: "MusicAlbum",
              collectionTypes: "audiobooks",
              shape: "autooverflow",
              preferThumb: !1,
              fields: instance ? [] : ["Name", "ParentName"],
              centerText: !0,
              overlayPlayButton: !0,
              bottomPadding: instance ? "focuspreview" : null,
            })),
          sections.push({
            name: "HeaderFavoritePhotos",
            types: "Photo",
            shape: "autooverflow",
            preferThumb: !1,
            fields: instance ? [] : ["Name", "ProductionYear"],
            centerText: !0,
            bottomPadding: instance ? "focuspreview" : null,
          }),
          sections.push({
            name: "HeaderFavoriteGames",
            types: "Game",
            shape: "autooverflow",
            preferThumb: !1,
            fields: instance ? [] : ["Name", "ParentName", "ProductionYear"],
            centerText: !0,
            bottomPadding: instance ? "focuspreview" : null,
          }),
          sections.push({
            name: "HeaderFavoritePeople",
            types: "Person",
            shape: "autooverflow",
            fields: instance ? [] : ["Name"],
            centerText: !0,
            bottomPadding: instance ? "focuspreview" : null,
          }),
          sections
        );
      })(instance, apiClient),
      html = "",
      clickTitles =
        !_layoutmanager.default.tv || !instance.enableFocusPreview();
    for (i = 0, length = sections.length; i < length; i++) {
      var section = sections[i],
        sectionClass = "verticalSection verticalSection-cards",
        sectionTitleContainerClass =
          "sectionTitleContainer padded-left padded-left-page padded-right",
        sectionClass =
          (clickTitles && (sectionTitleContainerClass += " focusable"),
          section.sideFooter && !_layoutmanager.default.tv
            ? ((sectionClass += " verticalSection-extrabottompadding"),
              (sectionTitleContainerClass +=
                " sectionTitleContainer-wrappedlistview"))
            : (sectionTitleContainerClass += " sectionTitleContainer-cards"),
          (html =
            html +
            ('<div class="' + sectionClass + ' hide">') +
            ('<div class="' +
              sectionTitleContainerClass +
              '" data-focusabletype="nearest">')),
          clickTitles &&
            (html +=
              '<a is="emby-sectiontitle" href="' +
              (function (section, serverId) {
                return _approuter.default.getRouteUrl("list", {
                  serverId: serverId,
                  itemTypes: section.types,
                  isFavorite: !0,
                });
              })(section, apiClient.serverId()) +
              '" class="noautofocus more button-link  button-link-color-inherit sectionTitleTextButton">'),
          (html =
            (html += '<h2 class="sectionTitle sectionTitle-cards">') +
            _globalize.default.translate(section.name) +
            "</h2>"),
          clickTitles && (html += "</a>"),
          (html += "</div>"),
          "itemsContainer scrollSlider focusable focuscontainer-x"),
        sectionTitleContainerClass =
          (section.sideFooter &&
            (sectionClass += " itemsContainer-sideFooters"),
          section.cardSizeOffset ? ' data-cardsizeoffset="1"' : "");
      html =
        html +
        ('<div is="emby-scroller" class="padded-top-focusscale padded-bottom-focusscale padded-left padded-left-page padded-right" data-mousewheel="false" data-focusscroll="true"><div is="emby-itemscontainer"' +
          sectionTitleContainerClass +
          ' data-focusabletype="nearest" class="' +
          sectionClass +
          '" data-monitor="markfavorite" data-virtualscrolllayout="horizontal-grid"></div></div>') +
        "</div>";
    }
    (html += '<div class="padded-bottom-page"></div>'), (elem.innerHTML = html);
    var elems = elem.querySelectorAll(".itemsContainer");
    for (i = 0, length = elems.length; i < length; i++) {
      var itemsContainer = elems[i];
      (itemsContainer.fetchData = (function (section) {
        return function (query) {
          var apiClient = this.apiClient,
            fields = this.getRequestedItemFields() + ",PrimaryImageAspectRatio",
            fields =
              (section.fields.includes("ProductionYear") &&
                ((fields += ",ProductionYear"), "Series" === section.types) &&
                (fields += ",Status,EndDate"),
              Object.assign(
                {
                  SortBy:
                    "Episode" === section.types
                      ? "SeriesSortName,ParentIndexNumber,IndexNumber,SortName"
                      : "SortName",
                  SortOrder: "Ascending",
                  Filters: "IsFavorite",
                  Recursive: !0,
                  Fields: fields,
                  CollapseBoxSetItems: !1,
                  CollectionTypes: section.collectionTypes,
                },
                query || {}
              )),
            query =
              ("TvChannel" === section.types &&
                ((fields.SortBy = "ChannelNumber,SortName"),
                (fields.Fields += ",CurrentProgram")),
              apiClient.getCurrentUserId());
          return "MusicArtist" === section.types
            ? apiClient.getArtists(query, fields)
            : "Person" === section.types
            ? apiClient.getPeople(query, fields)
            : ((fields.IncludeItemTypes = section.types),
              apiClient.getItems(query, fields));
        };
      })(sections[i]).bind(instance)),
        (itemsContainer.getListOptions = (function (section) {
          return function (items) {
            return section.sideFooter && !_layoutmanager.default.tv
              ? {
                  renderer: _listview.default,
                  options: {
                    action: "playallfromhere",
                    overlayPlayButton: !1,
                    verticalWrap: !0,
                    mediaInfo: !1,
                    enableSideMediaInfo: !1,
                    enableUserDataButtons: !1,
                    fields: ["Name", "ParentName"],
                  },
                  virtualScrollLayout: "horizontal-grid",
                }
              : {
                  renderer: _cardbuilder.default,
                  options: {
                    preferThumb: section.preferThumb,
                    shape: section.shape,
                    sideFooter: section.sideFooter,
                    centerText: section.centerText,
                    fields: section.fields,
                    scalable: !0,
                    overlayPlayButton: section.overlayPlayButton,
                    action: section.action,
                    channelNumberFirst: !0,
                    focusTransformTitleAdjust: !0,
                    programIndicators: section.programIndicators,
                  },
                  virtualScrollLayout: "horizontal-grid",
                };
          };
        })(sections[i]).bind(instance)),
        (itemsContainer.parentContainer =
          itemsContainer.closest(".verticalSection")),
        instance.addFocusBehavior(itemsContainer);
    }
    this.onUserDataChangedFn = function (e, apiClient, userData) {
      this.paused && (this.needsRefresh = !0);
    }.bind(this);
    elem = this.onUserDataChangedFn;
    elem && _events.default.on(_api.default, "UserDataChanged", elem);
  }
  Object.defineProperty(_exports, "__esModule", { value: !0 }),
    (_exports.default = void 0),
    Object.assign(FavoritesTab.prototype, _basetab.default.prototype),
    (FavoritesTab.prototype.enablePushDownFocusPreview = function () {
      return (
        _layoutmanager.default.tv &&
        _usersettings.default.enableHomescreenFocusPreviews() &&
        "y" === this.scrollDirection()
      );
    }),
    (FavoritesTab.prototype.onResume = function (options) {
      _basetab.default.prototype.onResume.apply(this, arguments);
      for (
        var promises = [],
          elems =
            (this.needsRefresh &&
              ((this.needsRefresh = !1),
              ((options = options || {}).refresh = !0)),
            this.sectionsContainer.querySelectorAll(".itemsContainer")),
          i = 0,
          length = elems.length;
        i < length;
        i++
      )
        promises.push(elems[i].resume(options));
      var instance = this;
      return Promise.all(promises).then(function () {
        options.autoFocus && instance.autoFocus(),
          instance.fillFocusPreviewIfNeeded();
      });
    }),
    (FavoritesTab.prototype.onPause = function () {
      _basetab.default.prototype.onPause.apply(this, arguments);
      for (
        var elems = this.sectionsContainer.querySelectorAll(".itemsContainer"),
          i = 0,
          length = elems.length;
        i < length;
        i++
      )
        elems[i].pause();
    }),
    (FavoritesTab.prototype.destroy = function () {
      _basetab.default.prototype.destroy.apply(this, arguments);
      for (
        var onUserDataChangedFn = this.onUserDataChangedFn,
          elems =
            (onUserDataChangedFn &&
              _events.default.off(
                _api.default,
                "UserDataChanged",
                onUserDataChangedFn
              ),
            (this.onUserDataChangedFn = null),
            this.sectionsContainer.querySelectorAll(".itemsContainer")),
          i = 0,
          length = elems.length;
        i < length;
        i++
      )
        (elems[i].fetchData = null),
          (elems[i].getListOptions = null),
          (elems[i].parentContainer = null);
      this.sectionsContainer = null;
    });
  _exports.default = FavoritesTab;
});
