define([
    "exports",
    "./../modules/tabbedview/basetab.js",
    "./../modules/loading/loading.js",
    "./../modules/homesections/homesections.js",
    "./../modules/emby-elements/emby-itemscontainer/emby-itemscontainer.js",
    "./../modules/emby-apiclient/connectionmanager.js",
    "./../modules/common/usersettings/usersettings.js",
    "./../modules/layoutmanager.js",
    "./../modules/appheader/appheader.js",
    "./../modules/skinviewmanager.js",
    "./../modules/common/globalize.js",
], function (
    _exports,
    _basetab,
    _loading,
    _homesections,
    _embyItemscontainer,
    _connectionmanager,
    _usersettings,
    _layoutmanager,
    _appheader,
    _skinviewmanager,
    _globalize
) {
    function HomeTab(view, params) {
        _basetab.default.apply(this, arguments),
            (this.view = view),
            (this.params = params),
            (this.apiClient = _connectionmanager.default.currentApiClient()),
            (this.sectionsContainer = view.querySelector(".sections")),
            view.querySelector(".sections").addEventListener(
                "settingschange",
                function () {
                    (this.sectionsRendered = !1),
                        this.paused || this.onResume({ refresh: !0 });
                }.bind(this)
            );
    }
    function autoFocus() {
        !this.instance.autoFocus() && this.retries < 20
            ? (this.retries++, setTimeout(autoFocus.bind(this), 100))
            : ((this.view = null), (this.retries = null));
    }
    Object.defineProperty(_exports, "__esModule", { value: !0 }),
        (_exports.default = void 0),
        Object.assign(HomeTab.prototype, _basetab.default.prototype),
        (HomeTab.prototype.enablePushDownFocusPreview = function () {
            return (
                _layoutmanager.default.tv &&
                _usersettings.default.enableHomescreenFocusPreviews() &&
                "y" === this.scrollDirection()
            );
        }),
        (HomeTab.prototype.onResume = function (options) {
            var serverName;
            return (
                _skinviewmanager.default.getSkinOptions().showTitleOnHomeTab &&
                ((serverName = _connectionmanager.default
                    .currentApiClient()
                    .serverName()),
                    (serverName =
                        _globalize.default.translate("Home") + " - " + serverName),
                    _appheader.default.setTitle(serverName)),
                _basetab.default.prototype.onResume.apply(this, arguments),
                this.sectionsRendered
                    ? (serverName = this.sectionsContainer)
                        ? _homesections.default.resume(serverName, options)
                        : Promise.resolve()
                    : this.refresh(options)
            );
        }),
        (HomeTab.prototype.refresh = function (options) {
            _loading.default.show();
            var view = this.view,
                apiClient = this.apiClient,
                instance =
                    (this.destroyHomeSections(), (this.sectionsRendered = !0), this);
            return apiClient.getCurrentUser().then(function (user) {
                return _homesections.default
                    .loadSections({
                        element: view.querySelector(".sections"),
                        apiClient: apiClient,
                        user: user,
                        requestedItemFields: instance.getRequestedItemFields(),
                        requestedImageTypes: instance.getRequestedImageTypes(),
                        enableFocusPreview: instance.enableFocusPreview(),
                    })
                    .then(function () {
                        instance.addFocusBehavior(view),
                            options.autoFocus &&
                            !instance.autoFocus() &&
                            setTimeout(
                                autoFocus.bind({ retries: 0, instance: instance }),
                                100
                            ),
                            _loading.default.hide();
                    });
            });
        }),
        (HomeTab.prototype.onPause = function () {
            _basetab.default.prototype.onPause.apply(this, arguments);
            var sectionsContainer = this.sectionsContainer;
            sectionsContainer && _homesections.default.pause(sectionsContainer);
        }),
        (HomeTab.prototype.destroy = function () {
            _basetab.default.prototype.destroy.apply(this, arguments),
                this.destroyHomeSections(),
                (this.sectionsContainer = null);
        }),
        (HomeTab.prototype.destroyHomeSections = function () {
            var sectionsContainer = this.sectionsContainer;
            sectionsContainer && (sectionsContainer.innerHTML = "");
        });
    _exports.default = HomeTab;
});
