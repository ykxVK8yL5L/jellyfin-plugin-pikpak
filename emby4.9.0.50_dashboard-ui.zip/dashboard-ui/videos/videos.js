define([
  "exports",
  "./../modules/tabbedview/tabbedview.js",
  "./../modules/common/globalize.js",
  "./../modules/emby-elements/emby-itemscontainer/emby-itemscontainer.js",
  "./../modules/emby-elements/emby-button/emby-button.js",
  "./../modules/emby-elements/emby-scroller/emby-scroller.js",
], function (
  _exports,
  _tabbedview,
  _globalize,
  _embyItemscontainer,
  _embyButton,
  _embyScroller
) {
  function HomeVideosView(view, params) {
    _tabbedview.default.apply(this, arguments);
  }
  Object.defineProperty(_exports, "__esModule", { value: !0 }),
    (_exports.default = void 0),
    Object.assign(HomeVideosView.prototype, _tabbedview.default.prototype),
    (HomeVideosView.prototype.getTabs = function () {
      var item =
        this.item.Subviews ||
        ("musicvideos" === (item = this.item).CollectionType
          ? ["videos", "folders"]
          : "homevideos" === item.CollectionType
          ? ["videos", "photos", "folders", "folders"]
          : "movies" === item.CollectionType
          ? ["videos", "trailers", "collections", "genres", "folders"]
          : []);
      return [
        {
          name: _globalize.default.translate("Shows"),
          id: "series",
          enabled: item.includes("series"),
        },
        {
          name:
            this.item.CollectionType && "movies" !== this.item.CollectionType
              ? _globalize.default.translate("Videos")
              : _globalize.default.translate("Movies"),
          id: "videos",
          enabled: item.includes("videos") || item.includes("movies"),
        },
        {
          name: _globalize.default.translate("Suggestions"),
          id: "suggestions",
          enabled: "movies" === this.item.CollectionType,
        },
        {
          name: _globalize.default.translate("Trailers"),
          id: "trailers",
          enabled: "movies" === this.item.CollectionType,
        },
        {
          name: _globalize.default.translate("Photos"),
          id: "photos",
          enabled: item.includes("photos"),
        },
        {
          name: _globalize.default.translate("HeaderAlbumArtists"),
          id: "albumartists",
          enabled: item.includes("albumartists"),
        },
        {
          name: _globalize.default.translate("Artists"),
          id: "artists",
          enabled: item.includes("artists"),
        },
        {
          name: _globalize.default.translate("Playlists"),
          id: "playlists",
          enabled: item.includes("playlists"),
        },
        {
          name: _globalize.default.translate("Collections"),
          id: "collections",
          enabled: item.includes("collections"),
        },
        {
          name: _globalize.default.translate("Genres"),
          id: "genres",
          enabled: item.includes("genres"),
        },
        {
          name: _globalize.default.translate("Tags"),
          id: "tags",
          enabled: item.includes("tags"),
        },
        {
          name: _globalize.default.translate("Favorites"),
          id: "favorites",
          enabled: "movies" === this.item.CollectionType,
        },
        { name: _globalize.default.translate("Folders"), id: "folders" },
      ];
    }),
    (HomeVideosView.prototype.getAutoBackdropItemTypes = function () {
      return ["Movie", "Series", "MusicVideo", "Video"];
    }),
    (HomeVideosView.prototype.loadTabController = function (id) {
      switch (id) {
        case "suggestions":
          return Emby.importModule("./videos/moviesuggestions.js");
        case "photos":
          return Emby.importModule("./videos/photos.js");
        case "trailers":
          return Emby.importModule("./videos/trailers.js");
        case "albumartists":
        case "artists":
          return Emby.importModule("./modules/tabbedview/artiststab.js");
        case "collections":
          return Emby.importModule("./modules/tabbedview/collectionstab.js");
        case "playlists":
          return Emby.importModule("./modules/tabbedview/playliststab.js");
        case "genres":
          return Emby.importModule("./modules/tabbedview/genrestab.js");
        case "tags":
          return Emby.importModule("./modules/tabbedview/tagstab.js");
        case "videos":
        case "favorites":
          return Emby.importModule("./modules/tabbedview/videostab.js");
        case "folders":
          return Emby.importModule("./modules/tabbedview/folderstab.js");
        case "series":
          return Emby.importModule("./modules/tabbedview/seriestab.js");
        default:
          throw new Error("tab not found: " + id);
      }
    }),
    (HomeVideosView.prototype.getDefaultTabId = function () {
      return this.item.CollectionType ? null : "folders";
    }),
    (HomeVideosView.prototype.getTabControllerOptions = function (id) {
      var options = _tabbedview.default.prototype.getTabControllerOptions.apply(
        this,
        arguments
      );
      return (
        "favorites" === id
          ? "movies" === this.item.CollectionType &&
            ((options.itemType = "Movie"),
            (options.enableAlphaPicker = !0),
            (options.mode = "favorites"))
          : "genres" === id
          ? "movies" === this.item.CollectionType
            ? (options.queryIncludeItemTypes = ["Movie"])
            : "musicvideos" === this.item.CollectionType
            ? (options.queryIncludeItemTypes = ["MusicVideo"])
            : "homevideos" === this.item.CollectionType &&
              (options.queryIncludeItemTypes = ["Video", "Photo"])
          : "videos" === id &&
            ((options.itemType =
              "musicvideos" === this.item.CollectionType
                ? "MusicVideo"
                : this.item.CollectionType &&
                  "movies" !== this.item.CollectionType
                ? "Video"
                : "Movie"),
            (options.enableAlphaPicker = "Episode" !== options.itemType)),
        options
      );
    });
  _exports.default = HomeVideosView;
});
