define([
    "exports",
    "./../modules/viewmanager/basesettingsview.js",
    "./../modules/loading/loading.js",
    "./../modules/common/globalize.js",
    "./../modules/emby-elements/emby-input/emby-input.js",
    "./../modules/emby-elements/emby-button/emby-button.js",
    "./../modules/emby-elements/emby-toggle/emby-toggle.js",
    "./../modules/emby-elements/emby-select/emby-select.js",
    "./../modules/emby-elements/emby-scroller/emby-scroller.js",
    "./../modules/emby-elements/emby-itemscontainer/emby-itemscontainer.js",
    "./../modules/layoutmanager.js",
    "./../modules/listview/listview.js",
    "./../modules/common/itemmanager/itemmanager.js",
    "./../modules/common/itemmanager/genericitemcontroller.js",
], function (
    _exports,
    _basesettingsview,
    _loading,
    _globalize,
    _embyInput,
    _embyButton,
    _embyToggle,
    _embySelect,
    _embyScroller,
    _embyItemscontainer,
    _layoutmanager,
    _listview,
    _itemmanager,
    _genericitemcontroller
) {
    function getLandingScreenOptionsHtml(type) {
        return (function (type) {
            var list = [];
            return (
                "movies" === type
                    ? (list.push({
                        name: _globalize.default.translate("Movies"),
                        value: "movies",
                        isDefault: !0,
                    }),
                        list.push({
                            name: _globalize.default.translate("Suggestions"),
                            value: "suggestions",
                        }),
                        list.push({
                            name: _globalize.default.translate("Favorites"),
                            value: "favorites",
                        }),
                        list.push({
                            name: _globalize.default.translate("Genres"),
                            value: "genres",
                        }),
                        list.push({
                            name: _globalize.default.translate("Collections"),
                            value: "collections",
                        }),
                        list.push({
                            name: _globalize.default.translate("Tags"),
                            value: "tags",
                        }),
                        list.push({
                            name: _globalize.default.translate("Folders"),
                            value: "folders",
                        }))
                    : "musicvideos" === type
                        ? (list.push({
                            name: _globalize.default.translate("Videos"),
                            value: "videos",
                            isDefault: !0,
                        }),
                            list.push({
                                name: _globalize.default.translate("Artists"),
                                value: "artists",
                            }),
                            list.push({
                                name: _globalize.default.translate("Genres"),
                                value: "genres",
                            }),
                            list.push({
                                name: _globalize.default.translate("Tags"),
                                value: "tags",
                            }),
                            list.push({
                                name: _globalize.default.translate("Folders"),
                                value: "folders",
                            }))
                        : "tvshows" === type
                            ? (list.push({
                                name: _globalize.default.translate("Shows"),
                                value: "shows",
                                isDefault: !0,
                            }),
                                list.push({
                                    name: _globalize.default.translate("Suggestions"),
                                    value: "suggestions",
                                }),
                                list.push({
                                    name: _globalize.default.translate("Favorites"),
                                    value: "favorites",
                                }),
                                list.push({
                                    name: _globalize.default.translate("Collections"),
                                    value: "collections",
                                }),
                                list.push({
                                    name: _globalize.default.translate("Genres"),
                                    value: "genres",
                                }),
                                list.push({
                                    name: _globalize.default.translate("Tags"),
                                    value: "tags",
                                }),
                                list.push({
                                    name: _globalize.default.translate("Networks"),
                                    value: "studios",
                                }),
                                list.push({
                                    name: _globalize.default.translate("Folders"),
                                    value: "folders",
                                }))
                            : "music" === type
                                ? (list.push({
                                    name: _globalize.default.translate("Suggestions"),
                                    value: "suggestions",
                                    isDefault: !0,
                                }),
                                    list.push({
                                        name: _globalize.default.translate("Albums"),
                                        value: "albums",
                                    }),
                                    list.push({
                                        name: _globalize.default.translate("HeaderAlbumArtists"),
                                        value: "albumartists",
                                    }),
                                    list.push({
                                        name: _globalize.default.translate("Artists"),
                                        value: "artists",
                                    }),
                                    list.push({
                                        name: _globalize.default.translate("Composers"),
                                        value: "composers",
                                    }),
                                    list.push({
                                        name: _globalize.default.translate("Playlists"),
                                        value: "playlists",
                                    }),
                                    list.push({
                                        name: _globalize.default.translate("Genres"),
                                        value: "genres",
                                    }),
                                    list.push({
                                        name: _globalize.default.translate("Tags"),
                                        value: "tags",
                                    }),
                                    list.push({
                                        name: _globalize.default.translate("Songs"),
                                        value: "songs",
                                    }),
                                    list.push({
                                        name: _globalize.default.translate("Folders"),
                                        value: "folders",
                                    }))
                                : "audiobooks" === type
                                    ? (list.push({
                                        name: _globalize.default.translate("Suggestions"),
                                        value: "suggestions",
                                        isDefault: !0,
                                    }),
                                        list.push({
                                            name: _globalize.default.translate("HeaderAudioBooks"),
                                            value: "albums",
                                        }),
                                        list.push({
                                            name: _globalize.default.translate("Authors"),
                                            value: "artists",
                                        }),
                                        list.push({
                                            name: _globalize.default.translate("Playlists"),
                                            value: "playlists",
                                        }),
                                        list.push({
                                            name: _globalize.default.translate("Genres"),
                                            value: "genres",
                                        }),
                                        list.push({
                                            name: _globalize.default.translate("Tags"),
                                            value: "tags",
                                        }),
                                        list.push({
                                            name: _globalize.default.translate("Folders"),
                                            value: "folders",
                                        }))
                                    : "livetv" === type
                                        ? (list.push({
                                            name: _globalize.default.translate("Suggestions"),
                                            value: "suggestions",
                                            isDefault: !0,
                                        }),
                                            list.push({
                                                name: _globalize.default.translate("Guide"),
                                                value: "guide",
                                            }),
                                            list.push({
                                                name: _globalize.default.translate("Channels"),
                                                value: "channels",
                                            }),
                                            list.push({
                                                name: _globalize.default.translate("Tags"),
                                                value: "tags",
                                            }))
                                        : "homevideos" === type
                                            ? (list.push({
                                                name: _globalize.default.translate("Videos"),
                                                value: "videos",
                                            }),
                                                list.push({
                                                    name: _globalize.default.translate("Photos"),
                                                    value: "photos",
                                                }),
                                                list.push({
                                                    name: _globalize.default.translate("Tags"),
                                                    value: "tags",
                                                }),
                                                list.push({
                                                    name: _globalize.default.translate("Folders"),
                                                    value: "folders",
                                                }))
                                            : type ||
                                            (list.push({
                                                name: _globalize.default.translate("Shows"),
                                                value: "shows",
                                            }),
                                                list.push({
                                                    name: _globalize.default.translate("Movies"),
                                                    value: "movies",
                                                }),
                                                list.push({
                                                    name: _globalize.default.translate("Collections"),
                                                    value: "collections",
                                                }),
                                                list.push({
                                                    name: _globalize.default.translate("Genres"),
                                                    value: "genres",
                                                }),
                                                list.push({
                                                    name: _globalize.default.translate("Tags"),
                                                    value: "tags",
                                                }),
                                                list.push({
                                                    name: _globalize.default.translate("Folders"),
                                                    value: "folders",
                                                })),
                list
            );
        })(type)
            .map(function (o) {
                return (
                    '<option value="' +
                    (o.isDefault ? "" : o.value) +
                    '">' +
                    o.name +
                    "</option>"
                );
            })
            .join("");
    }
    function renderPerLibrarySettings(context, user, userViews) {
        for (
            var context = context.querySelector(".perLibrarySettings"),
            html = "",
            i = 0,
            length = userViews.length;
            i < length;
            i++
        )
            html += (function (item, user) {
                var html = "",
                    folderId = item.Guid || item.Id;
                return (
                    ("Channel" !== item.Type &&
                        "boxsets" !== item.CollectionType &&
                        "playlists" !== item.CollectionType) ||
                    (html =
                        (html =
                            html +
                            '<label class="toggleContainer"><input type="checkbox" is="emby-toggle" class="chkIncludeInMyMedia" data-folderid="' +
                            folderId +
                            '"' +
                            (-1 ===
                                (user.Configuration.MyMediaExcludes || []).indexOf(folderId)
                                ? ' checked="checked"'
                                : "") +
                            "/>") +
                        "<span>" +
                        _globalize.default.translate("DisplayInMyMedia") +
                        "</span></label>"),
                    (html =
                        (html =
                            -1 ===
                                ["playlists", "livetv", "boxsets", "channels"].indexOf(
                                    item.CollectionType || ""
                                )
                                ? (html =
                                    html +
                                    '<label class="fldIncludeInLatest toggleContainer"><input type="checkbox" is="emby-toggle" class="chkIncludeInLatest" data-folderid="' +
                                    folderId +
                                    '"' +
                                    (-1 ===
                                        user.Configuration.LatestItemsExcludes.indexOf(folderId)
                                        ? ' checked="checked"'
                                        : "") +
                                    "/>") +
                                "<span>" +
                                _globalize.default.translate(
                                    "DisplayInOtherHomeScreenSections"
                                ) +
                                "</span></label>"
                                : html) && '<div class="fieldset-field">' + html + "</div>"),
                    ("movies" !== item.CollectionType &&
                        "tvshows" !== item.CollectionType &&
                        "musicvideos" !== item.CollectionType &&
                        "music" !== item.CollectionType &&
                        "audiobooks" !== item.CollectionType &&
                        "livetv" !== item.CollectionType &&
                        "homevideos" !== item.CollectionType &&
                        item.CollectionType) ||
                    ((folderId =
                        "landing-" +
                        (user =
                            "livetv" === item.CollectionType
                                ? item.CollectionType
                                : folderId)),
                        (html =
                            (html =
                                (html += '<div class="selectContainer fieldset-field">') +
                                '<select is="emby-select" class="selectLanding autoSetting autoSave" data-folderid="' +
                                user +
                                '" label="' +
                                _globalize.default.translate("LabelDefaultScreen") +
                                '" data-usersettingsfield="' +
                                folderId +
                                '" data-settingowner="usersettings">') +
                            getLandingScreenOptionsHtml(item.CollectionType) +
                            "</select></div>")),
                    html &&
                    ((user = ""),
                        (html =
                            (user =
                                (user = (user += "<fieldset>") + "<legend>" + item.Name) +
                                "</legend>" +
                                '<div class="fieldset-fields">') + html),
                        (user += "</div>"),
                        (html += "</fieldset>")),
                    html
                );
            })(userViews[i], user);
        context.innerHTML = html;
    }
    function getCheckboxItems(selector, context, isChecked) {
        for (
            var inputs = context.querySelectorAll(selector),
            list = [],
            i = 0,
            length = inputs.length;
            i < length;
            i++
        )
            inputs[i].checked === isChecked && list.push(inputs[i]);
        return list;
    }
    function mapUserViewToLibraryOrderItem(i, index, array) {
        return {
            ServerId: i.ServerId,
            Name: i.Name,
            Id: i.Guid || i.Id,
            Type: "GenericListItem",
            Icon: _itemmanager.default.getDefaultIcon(i),
            CanMoveUp: 0 < index,
            CanMoveDown: index < 10,
            CanReorder: !0,
        };
    }
    function onItemsMovedToNewIndex(instance, movedItems, options) {
        console.log("onItemsMovedToNewIndex");
        var obj,
            fromIndex = options.currentIndex,
            newIndex = options.newIndex;
        return (
            console.log(
                "onItemsMovedToNewIndex, fromIndex: " +
                fromIndex +
                ", newIndex: " +
                newIndex
            ),
            fromIndex === newIndex
                ? (console.log(
                    "fromIndex and newIndex are the same. something probably went wrong"
                ),
                    Promise.resolve())
                : (((obj = {}).OrderedViews = options.itemsContainer
                    .getItems()
                    .map(function (i) {
                        return i.Id;
                    })),
                    (function (arr, fromIndex, toIndex) {
                        var element = arr[fromIndex];
                        arr.splice(fromIndex, 1), arr.splice(toIndex, 0, element);
                    })(obj.OrderedViews, fromIndex, newIndex),
                    (options = instance.getApiClient()),
                    (fromIndex = instance.getUserConfigurationUserId()),
                    options.updatePartialUserConfiguration(fromIndex, obj))
        );
    }
    function getViewOrderListOptions(items) {
        return {
            renderer: _listview.default,
            options: {
                defaultBackground: !1,
                enableUserDataButtons: !1,
                moreButton: !1,
                mediaInfo: !1,
                action: _layoutmanager.default.tv ? "menu" : "none",
                hoverPlayButton: !1,
                multiSelect: !1,
                imagePlayButton: !1,
                dragReorder: !0,
                roundImage: !0,
                draggable: !0,
                contextMenu: !0,
                iconSpacing: !1,
                itemMarginY: !1,
                fields: ["Name"],
                commandActions: {
                    moveInOrder: function (items, options) {
                        return onItemsMovedToNewIndex(this, 0, options);
                    }.bind(this),
                },
            },
        };
    }
    function View(view, params) {
        _basesettingsview.default.apply(this, arguments),
            view.querySelector("form").addEventListener(
                "submit",
                function (e) {
                    return e && e.preventDefault(), !1;
                }.bind(this)
            ),
            view.addEventListener(
                "change",
                function (e) {
                    var fldIncludeInLatest,
                        apiClient = this.getApiClient(),
                        userId = this.getUserConfigurationUserId(),
                        context = e.target.closest("form"),
                        chkIncludeInMyMedia = e.target.closest(".chkIncludeInMyMedia");
                    chkIncludeInMyMedia
                        ? ((fldIncludeInLatest = chkIncludeInMyMedia
                            .closest("fieldset")
                            .querySelector(".fldIncludeInLatest")) &&
                            (chkIncludeInMyMedia.checked
                                ? fldIncludeInLatest.classList.remove("hide")
                                : fldIncludeInLatest.classList.add("hide")),
                            ((chkIncludeInMyMedia = {}).MyMediaExcludes = getCheckboxItems(
                                ".chkIncludeInMyMedia",
                                context,
                                !1
                            ).map(function (i) {
                                return i.getAttribute("data-folderid");
                            })),
                            apiClient.updatePartialUserConfiguration(
                                userId,
                                chkIncludeInMyMedia
                            ))
                        : e.target.closest(".chkIncludeInLatest") &&
                        (((fldIncludeInLatest = {}).LatestItemsExcludes =
                            getCheckboxItems(".chkIncludeInLatest", context, !1).map(
                                function (i) {
                                    return i.getAttribute("data-folderid");
                                }
                            )),
                            apiClient.updatePartialUserConfiguration(
                                userId,
                                fldIncludeInLatest
                            ));
                }.bind(this)
            );
        var viewOrderList = view.querySelector(".viewOrderList");
        (viewOrderList.fetchData = function (query) {
            return this.getApiClient()
                .getUserViews(
                    Object.assign({ IncludeHidden: !0 }, query),
                    this.getUserConfigurationUserId()
                )
                .then(function (result) {
                    return (
                        (result.Items = result.Items.map(mapUserViewToLibraryOrderItem)),
                        result
                    );
                });
        }.bind(this)),
            (viewOrderList.getListOptions = getViewOrderListOptions.bind(this));
    }
    Object.defineProperty(_exports, "__esModule", { value: !0 }),
        (_exports.default = void 0),
        Object.assign(View.prototype, _basesettingsview.default.prototype),
        (View.prototype.loadData = function () {
            var context = this.view,
                userId = (_loading.default.show(), this.getUserConfigurationUserId()),
                apiClient = this.getApiClient();
            return (
                (function (context) {
                    for (
                        var elems = context.querySelectorAll('option[value="nextup"]'),
                        i = 0,
                        length = elems.length;
                        i < length;
                        i++
                    )
                        elems[i].innerHTML =
                            _globalize.default.translate("HeaderNextUp") + " (Legacy)";
                })(context),
                apiClient.getUser(userId).then(function (user) {
                    return (function (context, user, apiClient) {
                        return (
                            (apiClient = apiClient.getUserViews(
                                { IncludeHidden: !0 },
                                user.Id
                            )),
                            Promise.all([apiClient]).then(function (responses) {
                                renderPerLibrarySettings(context, user, responses[0].Items),
                                    _loading.default.hide();
                            })
                        );
                    })(context, user, apiClient);
                })
            );
        }),
        (View.prototype.loadSettingsInternal = function () {
            var instance = this;
            return this.loadData().then(function () {
                return instance.loadAutoSettings();
            });
        }),
        (View.prototype.getUserConfigurationUserId = function () {
            return this.params.userId || this.getApiClient().getCurrentUserId();
        }),
        (View.prototype.onResume = function (options) {
            var result = _basesettingsview.default.prototype.onResume.apply(
                this,
                arguments
            ),
                viewOrderList = this.view.querySelector(".viewOrderList");
            return null != viewOrderList && viewOrderList.resume(options), result;
        }),
        (View.prototype.onPause = function () {
            _basesettingsview.default.prototype.onPause.apply(this, arguments);
            var viewOrderList = this.view.querySelector(".viewOrderList");
            null != viewOrderList && viewOrderList.pause();
        });
    _exports.default = View;
});
