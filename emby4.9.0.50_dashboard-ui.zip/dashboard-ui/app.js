!(function () {
  "use strict";
  var customPaths,
    appMode = globalThis.appMode,
    isNativeTizen = "tizen" === globalThis.appMode,
    isNativeLG = "webos" === globalThis.appMode;
  function returnFirstDependency(obj) {
    return obj;
  }
  function returnFirstDependencyDefault(obj) {
    var _obj;
    return (
      (null == (_obj = obj = Array.isArray(obj) ? obj[0] : obj)
        ? void 0
        : _obj.default) || obj
    );
  }
  function enableNativeGamepadKeyMapping() {
    return (
      window.navigator &&
      "string" == typeof window.navigator.gamepadInputEmulation &&
      (window.navigator.gamepadInputEmulation = "keyboard")
    );
  }
  function loadPlugin(url) {
    return Promise.all([
      importFromPath("./modules/common/pluginmanager.js"),
    ]).then(function (responses) {
      var pluginManager = responses[0];
      return url.startsWith("./") && url.endsWith(".js")
        ? (console.log("Loading plugin module: " + url),
          getDynamicImport(url)().then(function (f) {
            return pluginManager.loadPlugin(f, url);
          }))
        : pluginManager.loadPluginFromUrl(url);
    });
  }
  function returnFalse() {
    return !1;
  }
  function onApiClientCreated(e, apiClient) {
    ("ios" !== appMode && "android" !== appMode) ||
      ((apiClient._getAvailablePlugins = apiClient.getAvailablePlugins),
      (apiClient.getAvailablePlugins = function () {
        var promises = [
          this._getAvailablePlugins(),
          importFromPath("./modules/common/pluginmanager.js"),
        ];
        return Promise.all(promises).then(function (responses) {
          var plugins = responses[0],
            pluginManager = responses[1];
          return plugins.filter(function (p) {
            return pluginManager.allowPluginPages(p.guid);
          });
        });
      }.bind(apiClient))),
      Promise.all([importFromPath("./modules/browser.js")]).then(function (
        responses
      ) {
        responses[0].operaTv && (apiClient.isWebSocketSupported = returnFalse);
      });
  }
  function createConnectionManager() {
    return Promise.all([
      importFromPath("./modules/emby-apiclient/connectionmanager.js"),
      importFromPath("./modules/emby-apiclient/events.js"),
      importFromPath("./modules/common/servicelocator.js"),
    ]).then(function (outerResponses) {
      var accessToken,
        userId,
        connectionManager = outerResponses[0],
        events = outerResponses[1],
        outerResponses = outerResponses[2].appHost;
      (globalThis.Events = events),
        (connectionManager.globalScopeApiClient = !0),
        (connectionManager.devicePixelRatio = globalThis.devicePixelRatio),
        (globalThis.ConnectionManager = connectionManager),
        events.on(connectionManager, "apiclientcreated", onApiClientCreated),
        outerResponses.supports("multiserver") ||
          ((connectionManager.enableServerAddressValidation = !1),
          window.location.search &&
            ((accessToken = (events = new URLSearchParams(
              window.location.search
            )).get("accessToken")),
            (userId = events.get("userId")),
            (accessToken && userId && "1" === events.get("e")) ||
              (userId = accessToken = null)),
          console.log("creating ApiClient singleton"),
          (connectionManager.validateServerIds = !1),
          (outerResponses = window.location.href.toLowerCase()),
          (outerResponses =
            -1 !== (events = outerResponses.lastIndexOf("/web"))
              ? outerResponses.substring(0, events)
              : ((events =
                  (outerResponses = window.location).protocol +
                  "//" +
                  outerResponses.hostname),
                outerResponses.port && (events += ":" + outerResponses.port),
                events)),
          (events = connectionManager.getApiClientFromServerInfo(
            {
              ManualAddress: outerResponses,
              ManualAddressOnly: !0,
              IsLocalServer: !0,
              AccessToken: accessToken,
              UserId: userId,
            },
            outerResponses
          )),
          accessToken && userId && (window.location = "index.html"),
          (events.enableAutomaticNetworking = !1),
          console.log("loaded ApiClient singleton"));
    });
  }
  function getPluginPageContentPath() {
    return globalThis.ApiClient
      ? globalThis.ApiClient.getUrl("web/ConfigurationPage")
      : null;
  }
  function getDynamicImport(path) {
    return function () {
      return require(["".concat(path)]).then(returnFirstDependencyDefault);
    };
  }
  function importFromPath(path) {
    return getDynamicImport(path)();
  }
  function importFromPathWithoutExport(path) {
    return (function (path) {
      return function () {
        return require(["".concat(path)]);
      };
    })(path)();
  }
  function getNativeImport(objectName) {
    objectName = globalThis[objectName];
    return Promise.resolve(objectName);
  }
  function loadAppStorage() {
    var promise;
    try {
      localStorage.setItem("_test", "0"),
        localStorage.removeItem("_test"),
        (promise = importFromPath(
          "./modules/emby-apiclient/appstorage-localstorage.js"
        ));
    } catch (e) {
      promise = importFromPath("./modules/emby-apiclient/appstorage-memory.js");
    }
    return promise.then(function (appStorage) {
      return (appStorage.init ? appStorage.init() : Promise.resolve()).then(
        function () {
          return appStorage;
        }
      );
    });
  }
  function loadApiClient() {
    return (
      console.log("loadApiClient"),
      getDynamicImport("./modules/common/servicelocator.js")().then(function (
        serviceLocator
      ) {
        return loadAppHost()
          .then(function (appHost) {
            return (
              appHost.supports("sync")
                ? getDynamicImport("./modules/emby-apiclient/apiclientex.js")
                : getDynamicImport("./modules/emby-apiclient/apiclient.js")
            )();
          })
          .then(function (apiClientFactory) {
            return (
              serviceLocator.initialize({ apiClientFactory: apiClientFactory }),
              apiClientFactory
            );
          });
      })
    );
  }
  function supportsTizenNaclSockets() {
    var v;
    if (globalThis.tizen && globalThis.tizen.systeminfo)
      return (
        (v = globalThis.tizen.systeminfo.getCapability(
          "http://tizen.org/feature/platform.version"
        )),
        !supportsTizenWasmSockets() && v && parseFloat(v) >= parseFloat("2.4")
      );
  }
  function supportsTizenWasmSockets() {
    var v;
    if (globalThis.tizen && globalThis.tizen.systeminfo)
      return (
        (v = globalThis.tizen.systeminfo.getCapability(
          "http://tizen.org/feature/platform.version"
        )) && parseFloat(v) >= parseFloat("6.0")
      );
  }
  function loadServerDiscovery() {
    return customPaths.serverdiscovery
      ? getRequirePromise(addJsExtIfNeeded(customPaths.serverdiscovery))
      : isNativeTizen &&
        (supportsTizenNaclSockets() || supportsTizenWasmSockets())
      ? getRequirePromise("native/tizen/serverdiscovery")
      : "android" === appMode
      ? getRequirePromise("native/android/serverdiscovery")
      : "ios" === appMode
      ? getRequirePromise("native/ios/serverdiscovery")
      : getDynamicImport("./modules/emby-apiclient/serverdiscovery.js")();
  }
  function loadShell() {
    return customPaths.shell
      ? getRequirePromise(addJsExtIfNeeded(customPaths.shell))
      : "android" === appMode
      ? getRequirePromise("native/android/shell")
      : getDynamicImport("./modules/shell.js")();
  }
  function loadWakeOnLan() {
    return customPaths.wakeonlan
      ? getRequirePromise(addJsExtIfNeeded(customPaths.wakeonlan))
      : isNativeTizen &&
        (supportsTizenNaclSockets() || supportsTizenWasmSockets())
      ? getRequirePromise("native/tizen/wakeonlan")
      : "ios" === appMode
      ? getRequirePromise("native/ios/wakeonlan")
      : "android" === appMode
      ? getRequirePromise("native/android/wakeonlan")
      : getDynamicImport("./modules/emby-apiclient/wakeonlan.js")();
  }
  function loadFullscreenManager() {
    return getDynamicImport("./modules/common/servicelocator.js")().then(
      function (serviceLocator) {
        var promise = customPaths.fullscreenmanager
          ? getRequirePromise(customPaths.fullscreenmanager)
          : getDynamicImport("./modules/fullscreen/fullscreenmanager.js")();
        return promise.then(function (fullscreenManager) {
          return (
            serviceLocator.initialize({ fullscreenManager: fullscreenManager }),
            fullscreenManager
          );
        });
      }
    );
  }
  function loadIap() {
    return (
      console.log("loadIap"),
      ("android" === appMode
        ? getRequirePromise("native/android/iap")
        : "ios" === appMode
        ? getRequirePromise("native/ios/iap")
        : getDynamicImport("./modules/iap.js")()
      ).then(function (iapManager) {
        return getDynamicImport("./modules/common/servicelocator.js")().then(
          function (serviceLocator) {
            serviceLocator.initialize({ iapManager: iapManager });
          }
        );
      })
    );
  }
  function loadServiceLocator() {
    return (
      console.log("loadServiceLocator"),
      Promise.all([
        loadAppStorage(),
        loadAppHost(),
        loadShell(),
        loadFullscreenManager(),
        loadWakeOnLan(),
        loadServerDiscovery(),
      ]).then(function (responses) {
        console.log("loadServiceLocator - inner load 1");
        var appStorage = responses[0],
          appHost = responses[1],
          shell = responses[2],
          wakeOnLan = responses[4],
          serverDiscovery = responses[5],
          responses = [
            getDynamicImport("./modules/common/servicelocator.js")(),
          ];
        return (
          appHost.supports("sync") &&
            (responses.push(require(["filerepository"])),
            responses.push(require(["itemrepository"])),
            responses.push(require(["transfermanager"])),
            responses.push(require(["useractionrepository"])),
            responses.push(require(["localsync"]))),
          appHost.supports("cameraupload") &&
            responses.push(loadCameraUpload()),
          appHost.supports("applogger") && responses.push(loadAppLogger()),
          Promise.all(responses).then(function (responsesInner) {
            console.log("loadServiceLocator - inner load 2");
            var fileRepository,
              itemRepository,
              transferManager,
              userActionRepository,
              localSync,
              cameraUpload,
              appLogger,
              index = 0,
              serviceLocator = responsesInner[index];
            return (
              index++,
              appHost.supports("sync") &&
                ((fileRepository = responsesInner[index][0]),
                (itemRepository = responsesInner[++index][0]),
                (transferManager = responsesInner[++index][0]),
                (userActionRepository = responsesInner[++index][0]),
                (localSync = responsesInner[++index][0]),
                index++),
              appHost.supports("cameraupload") &&
                ((cameraUpload = responsesInner[index]), index++),
              appHost.supports("applogger") &&
                ((appLogger = responsesInner[index]), index++),
              console.log(
                "loadServiceLocator - calling serviceLocator.initialize"
              ),
              serviceLocator.initialize({
                appStorage: appStorage,
                appHost: appHost,
                shell: shell,
                wakeOnLan: wakeOnLan,
                serverDiscovery: serverDiscovery,
                fileRepository: fileRepository,
                itemRepository: itemRepository,
                transferManager: transferManager,
                userActionRepository: userActionRepository,
                cameraUpload: cameraUpload,
                appLogger: appLogger,
                localSync: localSync,
              }),
              console.log("loadServiceLocator - calling appHost.init"),
              appHost.init().then(loadApiClient).then(loadIap)
            );
          })
        );
      })
    );
  }
  function addJsExtIfNeeded(path) {
    return path.endsWith(".js") || (path += ".js"), path;
  }
  function getRequirePromise(dep) {
    return new Promise(function (resolve, reject) {
      require([dep], resolve);
    });
  }
  function loadAppLogger() {
    return "android" === appMode
      ? getRequirePromise("native/android/applogger")
      : Promise.resolve({
          getLogFiles: function (query) {
            var items = [],
              total =
                (items.push({
                  Name: "currentlog.txt",
                  Id: "currentlog.txt",
                  DateCreated: new Date().toISOString(),
                  DateModified: new Date().toISOString(),
                  Type: "Log",
                  CanDownload: !0,
                  CanShare: !0,
                }),
                items.length);
            return (
              query.StartIndex && (items = items.slice(query.StartIndex)),
              query.Limit &&
                (items.length = Math.min(query.Limit, items.length)),
              Promise.resolve({ Items: items, TotalRecordCount: total })
            );
          },
          getLogLines: function (query) {
            for (var items = [], i = 0; i < 1e4; i++) items.push("line " + i);
            var total = items.length;
            return (
              query.StartIndex && (items = items.slice(query.StartIndex)),
              query.Limit &&
                (items.length = Math.min(query.Limit, items.length)),
              Promise.resolve({ Items: items, TotalRecordCount: total })
            );
          },
          downloadLog: function (name) {
            return (
              console.log("downloading dummy log file: " + name),
              Promise.resolve()
            );
          },
          shareLog: function (name) {
            return (
              console.log("sharing dummy log file: " + name), Promise.resolve()
            );
          },
        });
  }
  function loadCameraUpload() {
    return "ios" === appMode
      ? getRequirePromise("native/ios/cameraupload")
      : "android" === appMode
      ? getRequirePromise("native/android/cameraupload")
      : Promise.resolve({
          start: function () {},
          setProgressUpdatesEnabled: function () {},
          getAvailableFolders: function () {
            return Promise.resolve([
              {
                Id: "541C6607-9C45-4875-A292-5F89F742B2B3/L0/040",
                Name: "TestFolder1",
              },
              {
                Id: "773DFE72-F38F-4220-8F2F-C4A472DBBA75/L0/040",
                Name: "TestFolder2",
              },
            ]);
          },
        });
  }
  function loadAppHost() {
    return customPaths.apphost
      ? getRequirePromise(addJsExtIfNeeded(customPaths.apphost))
      : "ios" === appMode
      ? getRequirePromise("native/ios/apphost")
      : "android" === appMode
      ? getRequirePromise("native/android/apphost")
      : importFromPath("./modules/apphost.js");
  }
  function initRequire() {
    for (
      var importMap = (function () {
          var elem = document.querySelector('script[type="importmap"]');
          if (elem) {
            elem = elem.innerHTML;
            if (elem)
              try {
                var obj = JSON.parse(elem);
                if (obj) {
                  var imports = obj.imports;
                  if (imports) return imports;
                }
              } catch (err) {
                console.log("error parsing import map: " + err);
              }
          }
          return {};
        })(),
        entries = Object.entries(importMap),
        i = 0,
        length = entries.length;
      i < length;
      i++
    ) {
      var entry = entries[i],
        key = entry[0],
        entry = entry[1];
      console.log("defining from importMap: " + key + ": " + entry),
        define(key, [], getDynamicImport(entry));
    }
    define("embyProgressBarStyle", [], returnFirstDependency),
      define("inputmanager", ["inputManager"], returnFirstDependency),
      define("fullscreenManager", loadFullscreenManager),
      define("shell", [], loadShell),
      customPaths.filesystem
        ? define(
            "filesystem",
            [addJsExtIfNeeded(customPaths.filesystem)],
            returnFirstDependency
          )
        : define(
            "filesystem",
            [],
            getDynamicImport("./modules/common/filesystem.js")
          ),
      define(
        "connectionManagerResolver",
        ["connectionManager"],
        returnFirstDependency
      ),
      define(
        "cardStyle",
        [
          "css!!aspectratio|modules/cardbuilder/cardpadder_legacy.css",
          "css!modules/cardbuilder/card.css",
          "css!!tv|modules/cardbuilder/card_nontv.css",
          "css!!varcalcmax,!containerqueries,!cssvars|modules/cardbuilder/card_sizes_base.css",
          "css!!varcalcmax,!containerqueries,cssvars|modules/cardbuilder/card_sizes_var.css",
          "css!varcalcmax,cssvars|modules/cardbuilder/card_sizes_varcalcmax.css",
          "css!modules/cardbuilder/card2.css",
          "css!!tv|modules/cardbuilder/card_nontv2.css",
          "css!tv|modules/cardbuilder/card_tv2.css",
          "css!modules/cardbuilder/card_post.css",
        ],
        returnFirstDependency
      ),
      define(
        "flexStyles",
        ["css!modules/flexstyles.css"],
        returnFirstDependency
      ),
      define(
        "programStyles",
        ["css!modules/emby-elements/guide/programs.css"],
        returnFirstDependency
      ),
      define("apphost", [], loadAppHost),
      define("cameraUpload", [], loadCameraUpload),
      define("appLogger", [], loadAppLogger),
      define("serverdiscovery", [], loadServerDiscovery),
      define("wakeOnLan", [], loadWakeOnLan),
      define("appStorage", [], loadAppStorage),
      define("clearButtonStyle", [], returnFirstDependency),
      define(
        "listViewStyle",
        ["css!modules/listview/listview.css"],
        returnFirstDependency
      ),
      define(
        "formDialogStyle",
        [
          "css!modules/formdialog/formdialog.css",
          "css!!tv|modules/formdialog/formdialog_nontv.css",
          "css!tv|modules/formdialog/formdialog_tv.css",
        ],
        returnFirstDependency
      ),
      define(
        "sectionsStyle",
        [
          "css!modules/sections/sections.css",
          "css!!tv|modules/sections/sections_nontv.css",
          "css!tv|modules/sections/sections_tv.css",
          "css!modules/sections/sections_post.css",
        ],
        returnFirstDependency
      ),
      define("mediasync", ["modules/sync/mediasync"], returnFirstDependency),
      define(
        "scrollStyles",
        [
          "css!!tv|modules/scroller/scroller_nontv.css",
          "css!modules/scroller/scroller.css",
        ],
        returnFirstDependency
      ),
      define("appsettings", ["appSettings"], returnFirstDependency),
      define(
        "material-icons",
        ["css!modules/fonts/material-icons/style.css"],
        returnFirstDependency
      ),
      define(
        "systemFontsCss",
        [
          "css!modules/fonts/fonts.css",
          "css!!tv,osx|modules/fonts/fonts_osx.css",
          "css!tv|modules/fonts/fonts_tv.css",
        ],
        returnFirstDependency
      ),
      define(
        "dialogTemplateHtml",
        ["text!modules/dialog/dialog.template.html"],
        returnFirstDependency
      ),
      define(
        "jQuery",
        ["https://code.jquery.com/jquery-3.7.0.slim.min.js"],
        function () {
          return (
            globalThis.ApiClient &&
              (globalThis.jQuery.ajax = globalThis.ApiClient.ajax),
            globalThis.jQuery
          );
        }
      ),
      define("apiInput", ["serverNotifications"], returnFirstDependency),
      define(
        "apiClientResolver",
        ["connectionManager"],
        function (connectionManager) {
          return function () {
            return connectionManager.currentApiClient();
          };
        }
      ),
      define("embyRouter", ["appRouter"], returnFirstDependency),
      define("webActionSheet", ["actionsheet"], returnFirstDependency),
      isNativeTizen &&
        supportsTizenNaclSockets() &&
        define(
          "sockets",
          ["native/tizen/naclSockets/sockets"],
          returnFirstDependency
        ),
      isNativeTizen &&
        supportsTizenWasmSockets() &&
        define(
          "sockets",
          ["native/tizen/wasmSockets/sockets"],
          returnFirstDependency
        ),
      define("iapManager", [], loadIap),
      define("detailtablecss", [], returnFirstDependency),
      define("apiclient", [], loadApiClient);
  }
  function loadHeader() {
    return (
      console.log("loadHeader"),
      Promise.all([importFromPath("./modules/appheader/appheader.js")]).then(
        function (responses) {
          return responses[0].init();
        }
      )
    );
  }
  function onAppReady() {
    "virtualKeyboard" in navigator &&
      (navigator.virtualKeyboard.overlaysContent = !0),
      console.log("onAppReady");
    var promises = [
      importFromPath("./modules/common/servicelocator.js"),
      importFromPath("./modules/approuter.js"),
      importFromPath("./modules/browser.js"),
    ];
    return (
      ("ios" !== appMode && "android" !== appMode) ||
        promises.push(
          importFromPath(
            "./modules/registrationservices/registrationservices.js"
          )
        ),
      "android" === appMode
        ? (promises.push(getRequirePromise("native/android/appshortcuts")),
          promises.push(getRequirePromise("native/android/nativecredentials")),
          promises.push(getRequirePromise("native/android/nativesettings")))
        : "ios" === appMode &&
          (promises.push(getRequirePromise("native/ios/appshortcuts")),
          promises.push(getRequirePromise("native/ios/nativecredentials")),
          promises.push(getRequirePromise("native/ios/nativesettings"))),
      Promise.all(promises).then(function (responses) {
        var appHost = responses[0].appHost,
          appRouter = responses[1],
          responses = responses[2];
        return (
          (promises = []),
          console.log("Loaded dependencies in onAppReady"),
          (function (appRouter, appHost) {
            console.log("Defining core routes"),
              appRouter.addRoute({
                path: "/startup/connectlogin.html",
                controller: "startup/connectlogin.js",
                controllerType: "module",
                anonymous: !0,
                startup: !0,
                defaultTitle: !0,
                clearBackdrop: !0,
                autoFocus: !1,
                adjustHeaderForEmbeddedScroll: !0,
                drawer: !1,
              }),
              appRouter.addRoute({
                path: "/startup/connectsignup.html",
                controller: "startup/connectsignup.js",
                controllerType: "module",
                anonymous: !0,
                startup: !0,
                defaultTitle: !0,
                clearBackdrop: !0,
                adjustHeaderForEmbeddedScroll: !0,
                drawer: !1,
              }),
              appRouter.addRoute({
                path: "/startup/welcome.html",
                controller: "startup/welcome.js",
                controllerType: "module",
                anonymous: !0,
                startup: !0,
                defaultTitle: !0,
                clearBackdrop: !0,
                adjustHeaderForEmbeddedScroll: !0,
                drawer: !1,
              }),
              appRouter.addRoute({
                path: "/startup/forgotpassword.html",
                controller: "startup/forgotpassword.js",
                controllerType: "module",
                anonymous: !0,
                startup: !0,
                defaultTitle: !0,
                clearBackdrop: !0,
                adjustHeaderForEmbeddedScroll: !0,
                drawer: !1,
              }),
              appRouter.addRoute({
                path: "/startup/forgotpasswordpin.html",
                controller: "startup/forgotpasswordpin.js",
                controllerType: "module",
                anonymous: !0,
                startup: !0,
                defaultTitle: !0,
                clearBackdrop: !0,
                adjustHeaderForEmbeddedScroll: !0,
                drawer: !1,
              }),
              appRouter.addRoute({
                path: "/home",
                contentPath: "/home/home.html",
                type: "home",
                defaultTitle: !0,
                controller: "home/home.js",
                controllerType: "module",
                autoFocus: !1,
                homeButton: !1,
                headerTabs: !0,
                adjustHeaderForEmbeddedScroll: !0,
                enableMediaControlTV: !0,
                title: "Home",
                icon: "&#xe88a;",
              }),
              appRouter.addRoute({
                path: "/home/home.html",
                contentPath: "/home/home.html",
                type: "home",
                defaultTitle: !0,
                controller: "home/home.js",
                controllerType: "module",
                autoFocus: !1,
                homeButton: !1,
                headerTabs: !0,
                adjustHeaderForEmbeddedScroll: !0,
                enableMediaControlTV: !0,
                title: "Home",
                icon: "&#xe88a;",
              }),
              appRouter.addRoute({
                path: "/home.html",
                contentPath: "/home/home.html",
                type: "home",
                defaultTitle: !0,
                controller: "home/home.js",
                controllerType: "module",
                autoFocus: !1,
                homeButton: !1,
                headerTabs: !0,
                adjustHeaderForEmbeddedScroll: !0,
                enableMediaControlTV: !0,
                title: "Home",
                icon: "&#xe88a;",
              }),
              appRouter.addRoute({
                path: "/home_horiz/home.html",
                type: "home",
                defaultTitle: !0,
                controller: "home_horiz/home.js",
                controllerType: "module",
                headerTabs: !0,
                autoFocus: !1,
                homeButton: !1,
                headerBackground: !1,
                clearBackdrop: !0,
                enableMediaControlTV: !0,
                title: "Home",
                icon: "&#xe88a;",
              }),
              appRouter.addRoute({
                path: "/list/list.html",
                controller: "list/list.js",
                controllerType: "module",
                autoFocus: !1,
                canRefresh: !0,
                adjustHeaderForEmbeddedScroll: !0,
                supportsThemeMedia: !0,
              }),
              appRouter.addRoute({
                contentPath: "/item/item.html",
                path: "/item",
                autoFocus: !1,
                controller: "item/item.js",
                controllerType: "module",
                transparentHeader: !0,
                adjustHeaderForEmbeddedScroll: !0,
                supportsThemeMedia: !0,
                transition: !0,
              }),
              appRouter.addRoute({
                contentPath: "/item/item.html",
                path: "/item/item.html",
                controller: "item/item.js",
                controllerType: "module",
                autoFocus: !1,
                transparentHeader: !0,
                adjustHeaderForEmbeddedScroll: !0,
                supportsThemeMedia: !0,
                transition: !0,
              }),
              appRouter.addRoute({
                contentPath: "/livetv/livetv.html",
                path: "/livetv",
                controller: "livetv/livetv.js",
                title: "LiveTV",
                controllerType: "module",
                autoFocus: !1,
                headerTabs: !0,
                adjustHeaderForEmbeddedScroll: !0,
                enableMediaControlTV: !0,
              }),
              appRouter.addRoute({
                path: "/startup/login.html",
                contentPath: "/list/list.html",
                controller: "startup/login.js",
                controllerType: "module",
                anonymous: !0,
                autoFocus: !1,
                startup: !0,
                defaultTitle: !0,
                clearBackdrop: !0,
                adjustHeaderForEmbeddedScroll: !0,
                drawer: !1,
              }),
              appRouter.addRoute({
                path: "/startup/manuallogin.html",
                controller: "startup/manuallogin.js",
                controllerType: "module",
                anonymous: !0,
                startup: !0,
                defaultTitle: !0,
                autoFocus: !1,
                clearBackdrop: !0,
                adjustHeaderForEmbeddedScroll: !0,
                drawer: !1,
              }),
              appRouter.addRoute({
                contentPath: "/books/books.html",
                path: "/books",
                controller: "books/books.js",
                controllerType: "module",
                autoFocus: !1,
                headerTabs: !0,
                adjustHeaderForEmbeddedScroll: !0,
              }),
              appRouter.addRoute({
                contentPath: "/games/games.html",
                path: "/games",
                controller: "games/games.js",
                controllerType: "module",
                autoFocus: !1,
                headerTabs: !0,
                adjustHeaderForEmbeddedScroll: !0,
              }),
              appRouter.addRoute({
                contentPath: "/videos/videos.html",
                path: "/videos",
                controller: "videos/videos.js",
                controllerType: "module",
                autoFocus: !1,
                headerTabs: !0,
                adjustHeaderForEmbeddedScroll: !0,
              }),
              appRouter.addRoute({
                contentPath: "/random/random.html",
                path: "/random",
                controller: "random/random.js",
                controllerType: "module",
                autoFocus: !1,
                headerTabs: !1,
                adjustHeaderForEmbeddedScroll: !0,
              }),
              appRouter.addRoute({
                contentPath: "/music/music.html",
                path: "/music",
                controller: "music/music.js",
                controllerType: "module",
                autoFocus: !1,
                headerTabs: !0,
                adjustHeaderForEmbeddedScroll: !0,
                enableMediaControlTV: !0,
              }),
              appRouter.addRoute({
                path: "/videoosd/videoosd.html",
                controller: "videoosd/videoosd.js",
                controllerType: "module",
                type: "video-osd",
                supportsThemeMedia: !0,
                enableMediaControl: !1,
                autoFocus: !1,
                headerBackground: !1,
                homeButton: !1,
                drawer: !1,
                dockedTabs: !1,
                backButton: !0,
                transparentHeader: !0,
                anonymous: !0,
              }),
              appRouter.addRoute({
                contentPath: "/settings/settings.html",
                path: "/settings",
                controller: "settings/settings.js",
                controllerType: "module",
                title: "Settings",
                autoFocus: !1,
                clearBackdrop: !0,
                settingsTheme: !0,
                drawer: !1,
                adjustHeaderForEmbeddedScroll: !0,
              }),
              appHost.supports("keyboardsettings") &&
                appRouter.addRoute({
                  path: "/settings/keyboard.html",
                  controller: "settings/keyboard.js",
                  controllerType: "module",
                  type: "settings",
                  title: "HeaderKeyboardAndRemote",
                  thumbImage: "",
                  order: 2,
                  icon: "&#xe312;",
                  clearBackdrop: !0,
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  autoFocus: !1,
                }),
              appHost.supports("applogger") &&
                (appRouter.addRoute({
                  path: "/applogs",
                  contentPath: "/logs/logs.html",
                  controller: "logs/logs.js",
                  autoFocus: !1,
                  controllerType: "module",
                  type: "settings",
                  icon: "folder_open",
                  clearBackdrop: !0,
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  navMenuId: "applogs",
                  title: "Logs",
                }),
                appRouter.addRoute({
                  path: "/applog",
                  contentPath: "/list/list.html",
                  autoFocus: !1,
                  controller: "logs/log.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  clearBackdrop: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  canRefresh: !0,
                  navMenuId: "applogs",
                  title: "Logs",
                })),
              appRouter.addRoute({
                path: "/settings/notifications.html",
                contentPath: "/list/list.html",
                controller: "settings/notifications.js",
                controllerType: "module",
                type: "settings",
                title: "Notifications",
                category: "Playback",
                thumbImage: "",
                order: 1001,
                icon: "&#xe7f4;",
                clearBackdrop: !0,
                settingsTheme: !0,
                settingsType: "user",
                adjustHeaderForEmbeddedScroll: !0,
                hideDrawerWithOtherUserIdParam: !0,
                featureId: "notifications",
                minServerVersion: "4.8.0.20",
              }),
              appRouter.addRoute({
                path: "/settings/playback.html",
                controller: "settings/playback.js",
                controllerType: "module",
                type: "settings",
                title: "Playback",
                category: "Playback",
                thumbImage: "",
                order: 2,
                icon: "&#xe038;",
                clearBackdrop: !0,
                settingsTheme: !0,
                settingsType: "user",
                adjustHeaderForEmbeddedScroll: !0,
                hideDrawerWithOtherUserIdParam: !0,
              }),
              appRouter.addRoute({
                path: "/settings/appgeneral.html",
                controller: "settings/appgeneral.js",
                controllerType: "module",
                type: "settings",
                title: "General",
                category: "General",
                thumbImage: "",
                order: 1,
                icon: "&#xe8b8;",
                clearBackdrop: !0,
                settingsTheme: !0,
                adjustHeaderForEmbeddedScroll: !0,
                hideDrawerWithOtherUserIdParam: !0,
              }),
              appRouter.addRoute({
                path: "/settings/appplayback.html",
                controller: "settings/appplayback.js",
                controllerType: "module",
                type: "settings",
                title: "Playback",
                category: "Playback",
                thumbImage: "",
                order: 1,
                icon: "&#xe038;",
                clearBackdrop: !0,
                settingsTheme: !0,
                adjustHeaderForEmbeddedScroll: !0,
                hideDrawerWithOtherUserIdParam: !0,
              }),
              appRouter.addRoute({
                path: "/settings/subtitles.html",
                controller: "settings/subtitles.js",
                controllerType: "module",
                type: "settings",
                title: "Subtitles",
                category: "Playback",
                thumbImage: "",
                order: 3,
                icon: "&#xe01c;",
                clearBackdrop: !0,
                settingsTheme: !0,
                settingsType: "user",
                adjustHeaderForEmbeddedScroll: !0,
                hideDrawerWithOtherUserIdParam: !0,
              }),
              appRouter.addRoute({
                path: "/settings/display.html",
                controller: "settings/display.js",
                controllerType: "module",
                type: "settings",
                title: "Display",
                category: "General",
                thumbImage: "",
                order: 0,
                icon: "&#xe333;",
                clearBackdrop: !0,
                settingsTheme: !0,
                settingsType: "user",
                adjustHeaderForEmbeddedScroll: !0,
                hideDrawerWithOtherUserIdParam: !0,
              }),
              appRouter.addRoute({
                path: "/settings/homescreen.html",
                controller: "settings/homescreen.js",
                controllerType: "module",
                type: "settings",
                title: "HeaderHomeScreen",
                category: "General",
                thumbImage: "",
                order: 1,
                icon: "&#xe88a;",
                clearBackdrop: !0,
                settingsTheme: !0,
                settingsType: "user",
                adjustHeaderForEmbeddedScroll: !0,
                hideDrawerWithOtherUserIdParam: !0,
              }),
              appRouter.addRoute({
                path: "/settings/profile.html",
                controller: "settings/profile.js",
                controllerType: "module",
                type: "settings",
                title: "Profile",
                icon: "person",
                clearBackdrop: !0,
                roles: "EnableUserPreferenceAccess",
                settingsTheme: !0,
                settingsType: "user",
                adjustHeaderForEmbeddedScroll: !0,
                hideDrawerWithOtherUserIdParam: !0,
              }),
              appHost.supports("cameraupload") &&
                appRouter.addRoute({
                  path: "/settings/cameraupload.html",
                  autoFocus: !1,
                  controller: "settings/cameraupload.js",
                  controllerType: "module",
                  type: "settings",
                  title: "HeaderCameraUpload",
                  clearBackdrop: !0,
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  icon: "photo_camera",
                }),
              appHost.supports("sync") &&
                appRouter.addRoute({
                  path: "/settings/download",
                  contentPath: "/settings/download/download.html",
                  controller: "settings/download/download.js",
                  controllerType: "module",
                  type: "settings",
                  icon: "&#xe5db;",
                  title: "Downloads",
                  clearBackdrop: !0,
                  settingsTheme: !0,
                  headerTabs: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                }),
              appRouter.addRoute({
                path: "/search",
                contentPath: "/search/search.html",
                controller: "search/search.js",
                controllerType: "module",
                title: "",
                autoFocus: !1,
                clearBackdrop: !0,
                searchButton: !1,
                adjustHeaderForEmbeddedScroll: !0,
                navMenuId: "search",
              }),
              appRouter.addRoute({
                path: "/startup/manualserver.html",
                controller: "startup/manualserver.js",
                controllerType: "module",
                anonymous: !0,
                startup: !0,
                defaultTitle: !0,
                clearBackdrop: !0,
                adjustHeaderForEmbeddedScroll: !0,
                drawer: !1,
              }),
              appRouter.addRoute({
                path: "/startup/selectserver.html",
                contentPath: "/list/list.html",
                autoFocus: !1,
                anonymous: !0,
                startup: !0,
                controller: "startup/selectserver.js",
                controllerType: "module",
                title: "HeaderSelectServer",
                clearBackdrop: !0,
                adjustHeaderForEmbeddedScroll: !0,
                drawer: !1,
                helpUrl:
                  "https://support.emby.media/support/solutions/articles/44001160340-emby-connect",
              }),
              appRouter.addRoute({
                contentPath: "/tv/tv.html",
                path: "/tv",
                controller: "tv/tv.js",
                controllerType: "module",
                autoFocus: !1,
                headerTabs: !0,
                adjustHeaderForEmbeddedScroll: !0,
              }),
              appHost.supports("serversetup") &&
                (appRouter.addRoute({
                  contentPath: "/plugins/addplugin.html",
                  path: "/plugins/install",
                  autoFocus: !1,
                  roles: "admin",
                  controller: "plugins/addpluginpage.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                  helpUrl:
                    "https://support.emby.media/support/solutions/articles/44001159720-plugins",
                  title: "Plugins",
                  icon: "add_shopping_cart",
                }),
                appRouter.addRoute({
                  path: "/database",
                  contentPath: "/server/database/database.html",
                  roles: "admin",
                  controller: "server/database/database.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                  title: "Database",
                  autoFocus: !1,
                  icon: "storage",
                }),
                appRouter.addRoute({
                  path: "/dashboard",
                  contentPath: "/dashboard/dashboard.html",
                  autoFocus: !1,
                  roles: "admin",
                  controller: "dashboard/dashboard.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                  title: "Dashboard",
                  icon: "dashboard",
                }),
                appRouter.addRoute({
                  path: "/dashboard.html",
                  contentPath: "/dashboard/dashboard.html",
                  autoFocus: !1,
                  roles: "admin",
                  controller: "dashboard/dashboard.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                  title: "Dashboard",
                  icon: "dashboard",
                }),
                appRouter.addRoute({
                  path: "/dashboard/settings",
                  contentPath: "/dashboard/settings.html",
                  controller: "dashboard/settings.js",
                  controllerType: "module",
                  autoFocus: !1,
                  roles: "admin",
                  settingsTheme: !0,
                  clearBackdrop: !0,
                  helpUrl:
                    "https://support.emby.media/support/solutions/articles/44001159322-server-settings",
                  title: "General",
                  adjustHeaderForEmbeddedScroll: !0,
                  icon: "settings",
                }),
                appRouter.addRoute({
                  contentPath: "/list/list.html",
                  path: "/devices",
                  autoFocus: !1,
                  roles: "admin",
                  controller: "devices/devices.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  clearBackdrop: !0,
                  helpUrl:
                    "https://support.emby.media/support/solutions/articles/44001159497-devices",
                  title: "Devices",
                  adjustHeaderForEmbeddedScroll: !0,
                  canRefresh: !0,
                  icon: "devices",
                }),
                appRouter.addRoute({
                  contentPath: "/network/network.html",
                  path: "/network",
                  autoFocus: !1,
                  roles: "admin",
                  controller: "network/network.js",
                  controllerType: "module",
                  title: "Network",
                  settingsTheme: !0,
                  clearBackdrop: !0,
                  helpUrl:
                    "https://support.emby.media/support/articles/Hosting-Settings.html",
                  adjustHeaderForEmbeddedScroll: !0,
                  icon: "wifi",
                }),
                appRouter.addRoute({
                  path: "/devices/device.html",
                  autoFocus: !1,
                  roles: "admin",
                  controller: "devices/device.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  clearBackdrop: !0,
                  helpUrl:
                    "https://support.emby.media/support/solutions/articles/44001159497-devices",
                  title: "Devices",
                  navMenuId: "devices",
                  adjustHeaderForEmbeddedScroll: !0,
                  icon: "devices",
                }),
                appRouter.addRoute({
                  path: "/devices/cameraupload.html",
                  autoFocus: !1,
                  roles: "admin",
                  controller: "devices/cameraupload.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  title: "HeaderCameraUpload",
                  clearBackdrop: !0,
                  helpUrl:
                    "https://support.emby.media/support/solutions/articles/44001159382-camera-upload",
                  adjustHeaderForEmbeddedScroll: !0,
                  icon: "photo_camera",
                }),
                appRouter.addRoute({
                  contentPath: "/metadatamanager/metadatamanager.html",
                  path: "/metadatamanager",
                  controller: "metadatamanager/metadatamanager.js",
                  controllerType: "module",
                  autoFocus: !1,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                  title: "MetadataManager",
                  icon: "edit",
                }),
                appRouter.addRoute({
                  contentPath: "/transcoding/transcoding.html",
                  path: "/transcoding",
                  autoFocus: !1,
                  roles: "admin",
                  controller: "transcoding/transcoding.js",
                  controllerType: "module",
                  title: "Transcoding",
                  settingsTheme: !0,
                  headerTabs: !0,
                  clearBackdrop: !0,
                  helpUrl:
                    "https://support.emby.media/support/solutions/articles/44001159897-transcoding",
                  adjustHeaderForEmbeddedScroll: !0,
                  icon: "transform",
                }),
                appRouter.addRoute({
                  path: "/librarysetup",
                  contentPath: "/librarysetup/librarysetup.html",
                  controller: "librarysetup/librarysetup.js",
                  controllerType: "module",
                  autoFocus: !1,
                  roles: "admin",
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                  headerTabs: !0,
                  title: "Library",
                  helpUrl:
                    "https://support.emby.media/support/solutions/articles/44001159319-library-setup",
                  navMenuId: "librarysetup",
                  icon: "folder",
                }),
                appRouter.addRoute({
                  path: "/livetvsetup",
                  contentPath: "/livetvsetup/livetvsetup.html",
                  controller: "livetvsetup/livetvsetup.js",
                  controllerType: "module",
                  autoFocus: !1,
                  roles: "admin",
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                  headerTabs: !0,
                  title: "LiveTV",
                  helpUrl:
                    "https://support.emby.media/support/solutions/articles/44001160415-live-tv-setup",
                  navMenuId: "livetvsetup",
                  icon: "dvr",
                }),
                appRouter.addRoute({
                  path: "/livetvsetup/guideprovider.html",
                  autoFocus: !1,
                  roles: "admin",
                  controller: "livetvsetup/guideprovider.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                  helpUrl:
                    "https://support.emby.media/support/solutions/articles/44001160415-live-tv-setup",
                  title: "LiveTV",
                  navMenuId: "livetvsetup",
                  icon: "dvr",
                }),
                appRouter.addRoute({
                  path: "/livetvsetup/livetvtuner.html",
                  autoFocus: !1,
                  roles: "admin",
                  controller: "livetvsetup/livetvtuner.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                  helpUrl:
                    "https://support.emby.media/support/solutions/articles/44001160415-live-tv-setup",
                  title: "HeaderTVSourceSetup",
                  navMenuId: "livetvsetup",
                  icon: "dvr",
                }),
                appRouter.addRoute({
                  path: "/logs",
                  contentPath: "/logs/logs.html",
                  controller: "logs/logs.js",
                  autoFocus: !1,
                  roles: "admin",
                  controllerType: "module",
                  settingsTheme: !0,
                  clearBackdrop: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  canRefresh: !0,
                  title: "Logs",
                  icon: "folder_open",
                }),
                appRouter.addRoute({
                  path: "/log",
                  contentPath: "/list/list.html",
                  autoFocus: !1,
                  roles: "admin",
                  controller: "logs/log.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  clearBackdrop: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  canRefresh: !0,
                  navMenuId: "logs",
                  title: "Logs",
                  icon: "folder_open",
                }),
                appRouter.addRoute({
                  path: "/plugins",
                  contentPath: "/plugins/plugins.html",
                  controller: "plugins/plugins.js",
                  controllerType: "module",
                  autoFocus: !1,
                  roles: "admin",
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                  headerTabs: !0,
                  title: "Plugins",
                  helpUrl:
                    "https://support.emby.media/support/solutions/articles/44001159720-plugins",
                  navMenuId: "plugins",
                  icon: "add_shopping_cart",
                }),
                appRouter.addRoute({
                  path: "/dashboard/releasenotes.html",
                  autoFocus: !1,
                  roles: "admin",
                  controller: "dashboard/releasenotes.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  clearBackdrop: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                }),
                appRouter.addRoute({
                  path: "/scheduledtasks",
                  contentPath: "/scheduledtasks/scheduledtasks.html",
                  roles: "admin",
                  autoFocus: !1,
                  controller: "scheduledtasks/scheduledtasks.js",
                  controllerType: "module",
                  title: "HeaderScheduledTasks",
                  clearBackdrop: !0,
                  settingsTheme: !0,
                  helpUrl:
                    "https://support.emby.media/support/solutions/articles/44001159751-scheduled-tasks",
                  navMenuId: "scheduledtasks",
                  adjustHeaderForEmbeddedScroll: !0,
                  icon: "schedule",
                }),
                appRouter.addRoute({
                  path: "/scheduledtask",
                  contentPath: "/list/list.html",
                  autoFocus: !1,
                  roles: "admin",
                  controller: "scheduledtasks/scheduledtask.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  clearBackdrop: !0,
                  helpUrl:
                    "https://support.emby.media/support/solutions/articles/44001159751-scheduled-tasks",
                  title: "HeaderScheduledTasks",
                  navMenuId: "scheduledtasks",
                  adjustHeaderForEmbeddedScroll: !0,
                  icon: "schedule",
                }),
                appRouter.addRoute({
                  path: "/serveractivity",
                  contentPath: "/list/list.html",
                  autoFocus: !1,
                  roles: "admin",
                  controller: "dashboard/serveractivity.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  clearBackdrop: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  canRefresh: !0,
                  navMenuId: "dashboard",
                }),
                appRouter.addRoute({
                  path: "/apikeys",
                  contentPath: "/list/list.html",
                  autoFocus: !1,
                  roles: "admin",
                  controller: "apikeys/apikeys.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  clearBackdrop: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  canRefresh: !0,
                  title: "HeaderApiKeys",
                  icon: "vpn_key",
                }),
                appRouter.addRoute({
                  contentPath: "/embypremiere/embypremiere.html",
                  path: "/embypremiere",
                  controller: "embypremiere/embypremiere.js",
                  controllerType: "module",
                  autoFocus: !1,
                  roles: "admin",
                  settingsTheme: !0,
                  clearBackdrop: !0,
                  helpUrl: "https://emby.media/premiere",
                  title: "Emby Premiere",
                  adjustHeaderForEmbeddedScroll: !0,
                  icon: "star",
                }),
                appRouter.addRoute({
                  path: "/serverdownloads",
                  contentPath: "server/sync/sync.html",
                  autoFocus: !1,
                  controller: "server/sync/sync.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  headerTabs: !0,
                  clearBackdrop: !0,
                  title: "Downloads",
                  icon: "&#xe5db;",
                }),
                appRouter.addRoute({
                  path: "/conversions",
                  contentPath: "server/sync/sync.html",
                  autoFocus: !1,
                  controller: "server/sync/sync.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  headerTabs: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                  title: "Conversions",
                  icon: "sync",
                }),
                appRouter.addRoute({
                  path: "/users/user",
                  contentPath: "/users/user.html",
                  controller: "users/user.js",
                  controllerType: "module",
                  autoFocus: !1,
                  roles: "admin",
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                  headerTabs: !0,
                  helpUrl:
                    "https://support.emby.media/support/solutions/articles/44001160237-users",
                  navMenuId: "users",
                }),
                appRouter.addRoute({
                  path: "/users/new",
                  contentPath: "/users/usernew.html",
                  controller: "users/usernew.js",
                  controllerType: "module",
                  autoFocus: !1,
                  roles: "admin",
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                  helpUrl:
                    "https://support.emby.media/support/solutions/articles/44001160237-users",
                  navMenuId: "users",
                  title: "HeaderNewUser",
                }),
                appRouter.addRoute({
                  path: "/users",
                  contentPath: "/list/list.html",
                  autoFocus: !1,
                  roles: "admin",
                  controller: "users/users.js",
                  controllerType: "module",
                  settingsTheme: !0,
                  clearBackdrop: !0,
                  helpUrl:
                    "https://support.emby.media/support/solutions/articles/44001160237-users",
                  adjustHeaderForEmbeddedScroll: !0,
                  canRefresh: !0,
                  title: "Users",
                  icon: "people",
                }),
                appRouter.addRoute({
                  path: "/wizard/wizardagreement.html",
                  anonymous: !0,
                  controller: "wizard/wizardagreement.js",
                  controllerType: "module",
                  homeButton: !1,
                  secondaryHeaderFeatures: !1,
                  defaultTitle: !0,
                  drawer: !1,
                  dockedTabs: !1,
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                }),
                appRouter.addRoute({
                  path: "/wizard/wizardremoteaccess.html",
                  anonymous: !0,
                  controller: "wizard/wizardremoteaccess.js",
                  controllerType: "module",
                  homeButton: !1,
                  secondaryHeaderFeatures: !1,
                  defaultTitle: !0,
                  drawer: !1,
                  dockedTabs: !1,
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                }),
                appRouter.addRoute({
                  path: "/wizard/wizardfinish.html",
                  anonymous: !0,
                  controller: "wizard/wizardfinishpage.js",
                  controllerType: "module",
                  homeButton: !1,
                  secondaryHeaderFeatures: !1,
                  defaultTitle: !0,
                  drawer: !1,
                  dockedTabs: !1,
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                }),
                appRouter.addRoute({
                  path: "/wizard/wizardlibrary.html",
                  controller: "wizard/wizardlibrary.js",
                  controllerType: "module",
                  anonymous: !0,
                  homeButton: !1,
                  secondaryHeaderFeatures: !1,
                  defaultTitle: !0,
                  drawer: !1,
                  dockedTabs: !1,
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                  helpUrl:
                    "https://support.emby.media/support/solutions/articles/44001159319-library-setup",
                }),
                appRouter.addRoute({
                  path: "/wizard/wizardstart.html",
                  anonymous: !0,
                  controller: "wizard/wizardstart.js",
                  controllerType: "module",
                  homeButton: !1,
                  secondaryHeaderFeatures: !1,
                  defaultTitle: !0,
                  drawer: !1,
                  dockedTabs: !1,
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                }),
                appRouter.addRoute({
                  path: "/wizard/wizarduser.html",
                  controller: "wizard/wizarduserpage.js",
                  controllerType: "module",
                  autoFocus: !1,
                  anonymous: !0,
                  homeButton: !1,
                  secondaryHeaderFeatures: !1,
                  defaultTitle: !0,
                  drawer: !1,
                  dockedTabs: !1,
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                }),
                appRouter.addRoute({
                  path: "/configurationpage",
                  autoFocus: !1,
                  enableCache: !1,
                  enableContentQueryString: !0,
                  roles: "admin",
                  contentPath: appHost.supports("multiserver")
                    ? getPluginPageContentPath
                    : null,
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  requiresDynamicTitle: !0,
                }),
                appRouter.addRoute({
                  path: "/genericui",
                  contentPath: "modules/genericui/genericui.html",
                  autoFocus: !1,
                  controller: "modules/genericui/genericui.js",
                  controllerType: "module",
                  enableContentQueryString: !0,
                  settingsTheme: !0,
                  adjustHeaderForEmbeddedScroll: !0,
                  clearBackdrop: !0,
                })),
              appRouter.addRoute({
                path: "/index.html",
                isDefaultRoute: !0,
                clearBackdrop: !0,
                autoFocus: !1,
              }),
              appRouter.addRoute({
                path: "/",
                isDefaultRoute: !0,
                clearBackdrop: !0,
              });
          })(appRouter, appHost),
          appRouter.start(),
          document.dispatchEvent(new CustomEvent("appready", {})),
          appHost.supports("soundeffects") &&
            importFromPath("./modules/soundeffects/soundeffectsmanager.js"),
          importFromPathWithoutExport("./modules/thememediaplayer.js"),
          importFromPathWithoutExport("./modules/transparencymanagement.js"),
          appHost.supports("nativegamepadkeymapping") ||
            enableNativeGamepadKeyMapping() ||
            !(
              "ongamepadconnected" in window ||
              navigator.getGamepads ||
              navigator.webkitGetGamepads
            ) ||
            (console.log("loading gamepadtokey"),
            importFromPathWithoutExport("./modules/input/gamepadtokey.js")),
          appHost.supports("webhidautoauth") &&
            importFromPath("./modules/input/hidinput.js").then(function (
              hidInput
            ) {
              hidInput.shouldTryConnect() &&
                window.addEventListener(
                  "keydown",
                  function () {
                    hidInput.tryConnect();
                  },
                  { capture: !0, passive: !0, once: !0 }
                );
            }),
          appHost.supports("windowstate") &&
            importFromPathWithoutExport("./modules/controlbox.js"),
          "android" === appMode
            ? require([
                "native/android/mediasession",
                "native/android/chromecast",
              ])
            : "ios" === appMode
            ? require([
                "native/ios/mediasession",
                "native/ios/backgroundfetch",
                "native/ios/nativeplayerbridge",
                "native/ios/mouse",
              ])
            : isNativeTizen &&
              (require(["native/tizen/input"]),
              require(["native/tizen/networkerror"]),
              responses.sdkVersion &&
                2.4 <= responses.sdkVersion &&
                require(["native/tizen/preview"]),
              require(["native/tizen/screensavermanager"]),
              (responses.tizenSideload = !1),
              responses.tizenSideload) &&
              require(["native/tizen/expiration"]),
          responses.tv ||
            importFromPathWithoutExport("./modules/notifications.js"),
          importFromPathWithoutExport(
            "./modules/nowplayingbar/nowplayingbar.js"
          ),
          appHost.supports("remotecontrol") &&
            importFromPathWithoutExport(
              "./modules/playback/remotecontrolautoplay.js"
            ),
          navigator.mediaSession &&
            !appHost.supports("nativemediasession") &&
            importFromPathWithoutExport("./modules/playback/mediasession.js"),
          Promise.all([
            importFromPath("./modules/cssloader.js"),
            importFromPath("./modules/input/mouse.js"),
          ]).then(function (responses) {
            var cssLoader = responses[0],
              responses = responses[1];
            cssLoader.init({ mouseManager: responses }), responses.init();
          }),
          importFromPath("./modules/input/keyboard.js"),
          importFromPath("./modules/common/input/api.js"),
          appHost.supports("screensaver") &&
            importFromPath("./modules/screensavermanager.js"),
          appHost.supports("fullscreenchange") &&
            importFromPathWithoutExport(
              "./modules/fullscreen/fullscreen-dc.js"
            ),
          appHost.supports("multiserver") ||
            (globalThis.ApiClient &&
              require(["css!" + globalThis.ApiClient.getUrl("Branding/Css")])),
          importFromPath("./modules/actionsheet/actionsheet.js"),
          require(["formDialogStyle"]),
          getDynamicImport(
            "./modules/common/playback/playbackmanager.js"
          )().then(function (playbackManager) {
            window.addEventListener("beforeunload", function (e) {
              try {
                playbackManager.onAppClose();
              } catch (err) {
                console.log("error in onAppClose: " + err);
              }
            });
          }),
          Promise.all(promises)
        );
      })
    );
  }
  function loadFirstLevelPresentationDependencies() {
    return (
      console.log("loadFirstLevelPresentationDependencies"),
      Promise.all([
        importFromPath("./modules/browser.js"),
        importFromPath("./modules/cssloader.js"),
      ]).then(function (responses) {
        var browser = responses[0],
          browser =
            ((appMode || browser.tv) &&
              "android" !== appMode &&
              (console.log = function () {}),
            require.setCssLoader(responses[1]),
            []);
        return (
          browser.push(
            require([
              "systemFontsCss",
              "flexStyles",
              "css!modules/layout/layout.css",
              "css!!tv|modules/layout/layout_nontv.css",
              "css!tv|modules/layout/layout_tv.css",
              "css!!cssvars|modules/layout/layout_nocssvars.css",
              "sectionsStyle",
            ])
          ),
          Promise.all(browser)
        );
      })
    );
  }
  function loadGlobalization() {
    return Promise.all([
      importFromPath("./modules/common/globalize.js"),
      importFromPath("./modules/common/servicelocator.js"),
    ]).then(function (responses) {
      var globalize = responses[0],
        responses = responses[1].appHost,
        stringPromises =
          (globalThis.urlCacheParam &&
            globalize.setCacheParam(globalThis.urlCacheParam),
          []);
      return (
        responses.supports("serversetup") &&
          stringPromises.push(
            (function (globalize) {
              var translations = [
                "ar",
                "be-BY",
                "bg-BG",
                "ca",
                "cs",
                "da",
                "de",
                "el",
                "en-GB",
                "en-US",
                "es",
                "es-AR",
                "es-MX",
                "fa",
                "fi",
                "fr",
                "fr-CA",
                "gsw",
                "he",
                "hi-IN",
                "hr",
                "hu",
                "id",
                "it",
                "ja",
                "kk",
                "ko",
                "lt-LT",
                "ms",
                "nb",
                "nl",
                "no",
                "pl",
                "pt-BR",
                "pt-PT",
                "ro",
                "ru",
                "sk",
                "sl-SI",
                "sv",
                "tr",
                "uk",
                "vi",
                "zh-CN",
                "zh-HK",
                "zh-TW",
              ].map(function (i) {
                return { lang: i, path: "strings/" + i + ".json" };
              });
              return globalize.loadStrings({
                name: "core",
                translations: translations,
              });
            })(globalize)
          ),
        stringPromises.push(
          (function (globalize) {
            var translations = [
              "ar",
              "bg-BG",
              "ca",
              "cs",
              "da",
              "de",
              "el",
              "en-GB",
              "en-US",
              "es",
              "es-AR",
              "es-MX",
              "et-EE",
              "fi",
              "fr",
              "fr-CA",
              "gsw",
              "he",
              "hr",
              "hu",
              "id",
              "it",
              "ja",
              "kk",
              "ko",
              "lt-LT",
              "ms",
              "nb",
              "nl",
              "pl",
              "pt-BR",
              "pt-PT",
              "ro",
              "ru",
              "sk",
              "sl-SI",
              "sv",
              "tr",
              "uk",
              "vi",
              "zh-CN",
              "zh-HK",
              "zh-TW",
            ].map(function (i) {
              return { lang: i, path: "modules/common/strings/" + i + ".json" };
            });
            return globalize.loadStrings({
              name: "sharedcomponents",
              translations: translations,
            });
          })(globalize)
        ),
        Promise.all(stringPromises)
      );
    });
  }
  function loadThirdLevelPolyfills() {
    return (
      console.log("loadThirdLevelPolyfills"),
      Promise.all([importFromPath("./modules/browser.js")]).then(function (
        responses
      ) {
        var responses = responses[0],
          _globalThis$NativeApp =
            ("embyclient" === appMode &&
            null != (_globalThis$NativeApp = globalThis.NativeAppHost) &&
            _globalThis$NativeApp.supports("sync")
              ? (define(
                  "transfermanager",
                  [],
                  getNativeImport("NativeTransferManager")
                ),
                define(
                  "filerepository",
                  [],
                  getNativeImport("NativeFileRepository")
                ),
                define("localsync", [], getNativeImport("NativeLocalSync")),
                define(
                  "itemrepository",
                  [],
                  getNativeImport("NativeItemRepository")
                ),
                define(
                  "useractionrepository",
                  [],
                  getNativeImport("NativeUserActionRepository")
                ))
              : "ios" === appMode
              ? (define(
                  "filerepository",
                  ["native/ios/filerepository"],
                  returnFirstDependency
                ),
                define(
                  "transfermanager",
                  ["filerepository"],
                  returnFirstDependency
                ),
                define(
                  "localsync",
                  ["native/ios/localsync"],
                  returnFirstDependency
                ),
                define(
                  "itemrepository",
                  ["native/ios/itemrepository"],
                  returnFirstDependency
                ),
                define(
                  "useractionrepository",
                  ["native/ios/useractionrepository"],
                  returnFirstDependency
                ))
              : "android" === appMode && AndroidAppHost.supportsSync()
              ? (define(
                  "transfermanager",
                  [],
                  getDynamicImport("./modules/sync/transfermanager.js")
                ),
                define(
                  "filerepository",
                  ["native/android/filerepository"],
                  returnFirstDependency
                ),
                define(
                  "localsync",
                  ["native/android/localsync"],
                  returnFirstDependency
                ),
                define(
                  "itemrepository",
                  ["native/android/itemrepository"],
                  returnFirstDependency
                ),
                define(
                  "useractionrepository",
                  ["native/android/useractionrepository"],
                  returnFirstDependency
                ))
              : (define(
                  "transfermanager",
                  [],
                  getDynamicImport("./modules/sync/transfermanager.js")
                ),
                define(
                  "filerepository",
                  [],
                  getDynamicImport("./modules/sync/filerepository.js")
                ),
                define(
                  "localsync",
                  [],
                  getDynamicImport("./modules/sync/localsync.js")
                ),
                define(
                  "itemrepository",
                  [],
                  getDynamicImport("./modules/localdatabase/itemrepository.js")
                ),
                define(
                  "useractionrepository",
                  [],
                  getDynamicImport(
                    "./modules/localdatabase/useractionrepository.js"
                  )
                )),
            []);
        return (
          "customElements" in globalThis
            ? ("customElements" in globalThis &&
                !responses.iOS &&
                !responses.safari &&
                customElements.upgrade) ||
              _globalThis$NativeApp.push(
                importFromPathWithoutExport(
                  "./modules/polyfills/custom-elements-builtin.js"
                )
              )
            : globalThis.MutationObserver && globalThis.Reflect
            ? _globalThis$NativeApp.push(
                require(["modules/polyfills/custom-elements"])
              )
            : _globalThis$NativeApp.push(
                require(["modules/polyfills/document-register-element"])
              ),
          isNativeTizen &&
            _globalThis$NativeApp.push(require(["native/tizen/tizeninfo"])),
          isNativeLG &&
            _globalThis$NativeApp.push(require(["native/webos/webosinfo"])),
          Promise.all(_globalThis$NativeApp)
        );
      })
    );
  }
  function loadSecondLevelPolyfills() {
    console.log("loadSecondLevelPolyfills");
    var _AbortSignal$prototyp,
      promises = [],
      isMissingRequestSignalSupport =
        ("undefined" == typeof SpeechRecognition &&
          (globalThis.SpeechRecognition = globalThis.webkitSpeechRecognition),
        "function" == typeof globalThis.Request &&
          !Object.prototype.hasOwnProperty.call(
            globalThis.Request.prototype,
            "signal"
          ));
    return (
      ("undefined" != typeof AbortSignal &&
        !isMissingRequestSignalSupport &&
        AbortSignal.timeout &&
        null != (_AbortSignal$prototyp = AbortSignal.prototype) &&
        _AbortSignal$prototyp.throwIfAborted) ||
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/abortsignal.js")
        ),
      ("undefined" != typeof AbortController &&
        !isMissingRequestSignalSupport) ||
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/abortcontroller.js")
        ),
      "undefined" != typeof AbortController &&
        isMissingRequestSignalSupport &&
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/abortablefetch.js")
        ),
      Number.isInteger ||
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/number.js")
        ),
      ("undefined" != typeof Intl && Intl.NumberFormat) ||
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/numberformat.js")
        ),
      ("undefined" != typeof Intl && Intl.DateTimeFormat) ||
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/datetimeformat.js")
        ),
      ("undefined" != typeof Intl && Intl.RelativeTimeFormat) ||
        promises.push(
          importFromPathWithoutExport(
            "./modules/polyfills/relativetimeformat.js"
          )
        ),
      ("undefined" != typeof Intl && Intl.DurationFormat) ||
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/durationformat.js")
        ),
      ("function" == typeof Object.assign &&
        "function" == typeof Object.create &&
        "function" == typeof Object.hasOwn) ||
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/object.js")
        ),
      ("function" == typeof Promise.any &&
        "function" == typeof Promise.allSettled) ||
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/promise.js")
        ),
      (String.prototype.includes &&
        String.prototype.startsWith &&
        String.prototype.endsWith &&
        String.prototype.replaceAll) ||
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/string.js")
        ),
      (Array.prototype.filter &&
        Array.prototype.includes &&
        Array.prototype.some &&
        Array.isArray &&
        Array.from) ||
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/array.js")
        ),
      (Element.prototype.matches &&
        Element.prototype.closest &&
        Element.prototype.remove &&
        Element.prototype.replaceChildren &&
        Element.prototype.append) ||
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/element.js")
        ),
      HTMLFormElement.prototype.requestSubmit ||
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/form.js")
        ),
      Function.prototype.bind ||
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/bind.js")
        ),
      "undefined" == typeof Map &&
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/map.js")
        ),
      "undefined" == typeof WeakMap &&
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/weakmap.js")
        ),
      ("undefined" != typeof Set && Set.prototype.entries) ||
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/set.js")
        ),
      ("undefined" != typeof crypto && crypto.randomUUID) ||
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/crypto.js")
        ),
      ("undefined" != typeof CSS && CSS.supports) ||
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/css.js")
        ),
      Promise.all(promises)
    );
  }
  function loadFirstLevelPolyfills() {
    var promises = [];
    return (
      globalThis.Emby.requiresClassesPolyfill &&
        promises.push(importFromPathWithoutExport("./modules/babelhelpers.js")),
      "undefined" == typeof ResizeObserver &&
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/resizeobserver.js")
        ),
      "undefined" == typeof IntersectionObserver &&
        promises.push(
          importFromPathWithoutExport(
            "./modules/polyfills/intersection-observer.js"
          )
        ),
      (function () {
        if ("undefined" == typeof URLSearchParams) return 1;
        try {
          return "+" !== new URLSearchParams("q=%2B").get("q") ||
            "+" !== new URLSearchParams({ q: "+" }).get("q") ||
            "+" !== new URLSearchParams([["q", "+"]]).get("q") ||
            "q=%0A" !== new URLSearchParams("q=\n").toString() ||
            "q=+%26" !== new URLSearchParams({ q: " &" }).toString() ||
            "q=%25zx" !== new URLSearchParams({ q: "%zx" }).toString()
            ? 1
            : void 0;
        } catch (error) {
          return 1;
        }
      })() &&
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/urlsearchparams.js")
        ),
      (function () {
        if ("undefined" == typeof DataTransfer) return 1;
        try {
          new DataTransfer();
        } catch (error) {
          return 1;
        }
      })() &&
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/datatransfer.js")
        ),
      "undefined" == typeof fetch &&
        promises.push(
          importFromPathWithoutExport("./modules/polyfills/fetch.js")
        ),
      Promise.all(promises)
    );
  }
  function start(startInfo) {
    if (
      (enableNativeGamepadKeyMapping(),
      "undefined" != typeof Windows && Windows.UI)
    ) {
      try {
        Windows.UI.ViewManagement.ApplicationViewScaling.trySetDisableLayoutScaling(
          !0
        );
      } catch (err) {}
      try {
        Windows.UI.ViewManagement.ApplicationView.getForCurrentView().setDesiredBoundsMode(
          Windows.UI.ViewManagement.ApplicationViewBoundsMode.useCoreWindow
        );
      } catch (err) {}
    }
    return (
      (startInfo = startInfo || globalThis.appStartInfo || {}),
      (customPaths = startInfo.paths || {}),
      initRequire(),
      loadFirstLevelPolyfills()
        .then(loadSecondLevelPolyfills, loadSecondLevelPolyfills)
        .then(loadThirdLevelPolyfills, loadThirdLevelPolyfills)
        .then(loadServiceLocator)
        .then(createConnectionManager)
        .then(loadGlobalization)
        .then(loadFirstLevelPresentationDependencies)
        .then(
          function () {
            console.log("loadPlugins");
            var startInfo = this;
            return Promise.all([
              importFromPath("./modules/common/servicelocator.js"),
              importFromPath("./modules/browser.js"),
              importFromPath("./modules/approuter.js"),
            ]).then(function (responses) {
              var forcedPlugins,
                appHost = responses[0].appHost,
                responses = responses[1],
                externalPlugins =
                  (appHost.supports("windowstate") &&
                    "embyclient" !== appMode &&
                    (document
                      .querySelector(".skinHeader")
                      .insertAdjacentHTML(
                        "beforeend",
                        '<div class="windowDragRegion hide-mouse-idle-tv"></div>'
                      ),
                    require(["css!modules/windowdrag.css"])),
                  startInfo.plugins || []);
              if (
                (console.log("Loading installed plugins"),
                customPaths.pluginloader)
              )
                return (
                  (forcedPlugins = [
                    "./modules/common/playback/playbackvalidation.js",
                    "./modules/common/playback/playaccessvalidation.js",
                    "./modules/common/playback/experimentalwarnings.js",
                    "./modules/htmlaudioplayer/plugin.js",
                    "./modules/photoplayer/plugin.js",
                    "./modules/confirmstillplaying/plugin.js",
                  ]),
                  getRequirePromise(
                    addJsExtIfNeeded(customPaths.pluginloader)
                  ).then(function (pluginloader) {
                    return pluginloader.loadPlugins(forcedPlugins);
                  })
                );
              var list = [
                "./modules/common/playback/playbackvalidation.js",
                "./modules/common/playback/playaccessvalidation.js",
                "./modules/common/playback/experimentalwarnings.js",
              ];
              appHost.supports("soundeffects") &&
                list.push(
                  "./modules/soundeffects/defaultsoundeffects/plugin.js"
                ),
                appHost.supports("screensaver") &&
                  (list.push("./modules/logoscreensaver/plugin.js"),
                  list.push("./modules/backdropscreensaver/plugin.js"),
                  list.push("./modules/photoscreensaver/plugin.js")),
                "android" === appMode
                  ? (list.push("native/android/mpvvideoplayer"),
                    list.push("native/android/mpvaudioplayer"))
                  : "ios" === appMode &&
                    (list.push("native/ios/mpvaudioplayer"),
                    list.push("native/ios/mpvvideoplayer")),
                "android" !== appMode &&
                  "ios" !== appMode &&
                  list.push("./modules/htmlaudioplayer/plugin.js"),
                "ios" === appMode && list.push("native/ios/chromecast"),
                "android" === appMode &&
                  (list.push("native/android/externalplayer"),
                  list.push("native/android/chromecast")),
                globalThis.webapis && webapis.avplay
                  ? list.push("native/tizen/tizenavplayer/plugin")
                  : "android" !== appMode &&
                    "ios" !== appMode &&
                    list.push("./modules/htmlvideoplayer/plugin.js"),
                list.push("./modules/photoplayer/plugin.js"),
                appHost.supports("remotecontrol") &&
                  (list.push("./modules/sessionplayer.js"),
                  globalThis.chrome) &&
                  !responses.electron &&
                  "android" !== appMode &&
                  list.push("./modules/chromecast/chromecastplayer.js"),
                (appHost.supports("youtube") || responses.electron) &&
                  list.push("./modules/youtubeplayer/plugin.js");
              for (var i = 0, length = externalPlugins.length; i < length; i++)
                list.push(externalPlugins[i]);
              return (
                responses.electron &&
                  list.push("./modules/externalplayer/plugin.js"),
                list.push("./modules/confirmstillplaying/plugin.js"),
                Promise.all(list.map(loadPlugin))
              );
            });
          }.bind(startInfo)
        )
        .then(
          function () {
            console.log("loadExternalScripts");
            var scripts = this.scripts;
            return scripts ? require(scripts) : Promise.resolve();
          }.bind(startInfo)
        )
        .then(loadHeader)
        .then(onAppReady)
    );
  }
  Object.entries ||
    (Object.entries = function (obj) {
      for (
        var ownProps = Object.keys(obj),
          i = ownProps.length,
          resArray = new Array(i);
        i--;

      )
        resArray[i] = [ownProps[i], obj[ownProps[i]]];
      return resArray;
    }),
    globalThis.Emby || (globalThis.Emby = {}),
    (Emby.importModule = importFromPath),
    (Emby.App = { start: start }),
    -1 ===
      globalThis.location.href
        .toString()
        .toLowerCase()
        .indexOf("autostart=false") && start();
})();
