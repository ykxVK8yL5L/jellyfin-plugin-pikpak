define([
    "exports",
    "./../dialoghelper/dialoghelper.js",
    "./../dom.js",
    "./../cardbuilder/cardbuilder.js",
    "./../listview/listview.js",
    "./../loading/loading.js",
    "./../emby-apiclient/connectionmanager.js",
    "./../focusmanager.js",
    "./../common/globalize.js",
    "./../common/servicelocator.js",
    "./../common/textencoding.js",
    "./../layoutmanager.js",
    "./../emby-elements/emby-input/emby-input.js",
    "./../emby-elements/emby-button/paper-icon-button-light.js",
    "./../emby-elements/emby-scroller/emby-scroller.js",
    "./../emby-elements/emby-toggle/emby-toggle.js",
    "./../emby-elements/emby-dialogclosebutton/emby-dialogclosebutton.js",
    "./../common/dialogs/confirm.js",
], function (
    _exports,
    _dialoghelper,
    _dom,
    _cardbuilder,
    _listview,
    _loading,
    _connectionmanager,
    _focusmanager,
    _globalize,
    _servicelocator,
    _textencoding,
    _layoutmanager,
    _embyInput,
    _paperIconButtonLight,
    _embyScroller,
    _embyToggle,
    _embyDialogclosebutton,
    _confirm
) {
    function showIdentifyOptions(instance, page, identifyResult) {
        var identifyOptionsForm = page.querySelector(".identifyOptionsForm"),
            identifyOptionsForm =
                (page.querySelector(".popupIdentifyForm").classList.add("hide"),
                    page
                        .querySelector(".identificationSearchResults")
                        .classList.add("hide"),
                    identifyOptionsForm.classList.remove("hide"),
                    (page.querySelector(".chkIdentifyReplaceImages").checked = !0),
                    []),
            identifyOptionsForm =
                (identifyOptionsForm.push(identifyResult.Name),
                    identifyResult.ProductionYear &&
                    identifyOptionsForm.push(identifyResult.ProductionYear),
                    identifyResult.GameSystem &&
                    identifyOptionsForm.push(identifyResult.GameSystem),
                    identifyOptionsForm.join("<br/>"));
        identifyResult.ImageUrl &&
            (identifyOptionsForm =
                '<div class="flex align-items-center"><img src="' +
                (function (apiClient, url, provider) {
                    return apiClient.getUrl("Items/RemoteSearch/Image", {
                        imageUrl: url,
                        ProviderName: provider,
                        api_key: apiClient.accessToken(),
                    });
                })(
                    _connectionmanager.default.getApiClient(instance.options.item),
                    identifyResult.ImageUrl,
                    identifyResult.SearchProviderName
                ) +
                '" style="max-height:240px;" /><div style="margin: 0 1em;">' +
                identifyOptionsForm +
                "</div>"),
            (page.querySelector(".selectedSearchResult").innerHTML =
                identifyOptionsForm),
            autoFocus.call(instance);
    }
    function autoFocus() {
        var dlg = this.dlg;
        _loading.default.hide(),
            _focusmanager.default.autoFocus(dlg, { skipIfNotEnabled: !0 });
    }
    function ItemIdentifier(options) {
        this.options = options;
    }
    function onItemsContainerUpgraded() {
        this.itemsContainer.resume({ refresh: !1 }).then(autoFocus.bind(this));
    }
    function mapToId(item) {
        return item.Id;
    }
    Object.defineProperty(_exports, "__esModule", { value: !0 }),
        (_exports.default = void 0),
        require(["formDialogStyle", "material-icons"]),
        (ItemIdentifier.prototype.afterRefresh = function (result) {
            result.length
                ? this.dlg.querySelector(".noResultsFound").classList.add("hide")
                : this.dlg.querySelector(".noResultsFound").classList.remove("hide");
        }),
        (ItemIdentifier.prototype.getItems = function (query) {
            _loading.default.show();
            var dlg = this.dlg;
            if (!dlg) return Promise.resolve([]);
            for (
                var value,
                item = this.options.item,
                apiClient = _connectionmanager.default.getApiClient(item),
                lookupInfo = { ProviderIds: {} },
                identifyField = dlg.querySelectorAll(".identifyField"),
                i = 0,
                length = identifyField.length;
                i < length;
                i++
            )
                (value = identifyField[i].value) &&
                    ("number" === identifyField[i].type && (value = parseInt(value)),
                        (lookupInfo[identifyField[i].getAttribute("data-lookup")] = value));
            var hasId = !1,
                txtLookupId = dlg.querySelectorAll(".txtLookupId");
            for (i = 0, length = txtLookupId.length; i < length; i++)
                (value = txtLookupId[i].value) &&
                    ((hasId = !0),
                        (lookupInfo.ProviderIds[
                            txtLookupId[i].getAttribute("data-providerkey")
                        ] = value));
            if (!hasId && !lookupInfo.Name) return Promise.resolve([]);
            item.GameSystem && (lookupInfo.GameSystem = item.GameSystem),
                (lookupInfo = { SearchInfo: lookupInfo }),
                item.Id
                    ? (lookupInfo.ItemId = item.Id)
                    : (lookupInfo.IncludeDisabledProviders = !0);
            var instance = this;
            return apiClient
                .ajax({
                    type: "POST",
                    url: apiClient.getUrl("Items/RemoteSearch/" + item.Type),
                    data: JSON.stringify(lookupInfo),
                    contentType: "application/json",
                    dataType: "json",
                })
                .then(function (results) {
                    return (
                        results.forEach(
                            function (item) {
                                var type = this.options.item.Type;
                                (item.Type = type),
                                    (item.IsFolder = "Series" === type || "MusicAlbum" === type),
                                    (item.PrimaryImageAspectRatio =
                                        "Movie" === type ||
                                            "Series" === type ||
                                            "Trailer" === type ||
                                            "BoxSet" === type ||
                                            "Person" === type
                                            ? 2 / 3
                                            : 1);
                                item.AlbumArtist && (item.AlbumArtists = [item.AlbumArtist]);
                                item.ShortOverview = item.DisambiguationComment;
                            }.bind(instance)
                        ),
                        results
                    );
                });
        }),
        (ItemIdentifier.prototype.getCardOptions = function (items) {
            var type = this.options.item.Type,
                fields = ["Name"];
            return (
                "Person" !== type &&
                "MusicArtist" !== type &&
                fields.push("ProductionYear"),
                ("Game" !== type && "MusicAlbum" !== type && "MusicVideo" !== type) ||
                fields.push("ParentName"),
                {
                    shape: "auto",
                    fields: fields,
                    overlayPlayButton: !1,
                    multiSelect: !1,
                    contextMenu: !1,
                    hoverMenu: !1,
                    action: "custom",
                    textLinks: !1,
                    lazy: 2,
                    draggable: !1,
                }
            );
        }),
        (ItemIdentifier.prototype.getListViewOptions = function (items) {
            var type = this.options.item.Type,
                fields = ["Name", "ShortOverview"];
            return (
                "Person" !== type &&
                "MusicArtist" !== type &&
                fields.push("ProductionYear"),
                ("Game" !== type && "MusicAlbum" !== type && "MusicVideo" !== type) ||
                fields.push("ParentName"),
                {
                    enableDefaultIcon: !0,
                    action: "custom",
                    fields: fields,
                    artist: "MusicAlbum" === type || "MusicVideo" === type,
                    draggable: !1,
                    draggableXActions: !1,
                    multiSelect: !1,
                    contextMenu: !1,
                    hoverPlayButton: !1,
                    imageSize: "medium",
                }
            );
        }),
        (ItemIdentifier.prototype.getListOptions = function (items) {
            return "MusicAlbum" === this.options.item.Type
                ? {
                    renderer: _listview.default,
                    options: this.getListViewOptions(items),
                }
                : {
                    renderer: _cardbuilder.default,
                    options: this.getCardOptions(items),
                    virtualScrollLayout: "vertical-grid",
                };
        }),
        (ItemIdentifier.prototype.show = function () {
            var item = this.options.item,
                instance = this;
            return require([
                "text!modules/itemidentifier/itemidentifier.template.html",
            ]).then(function (responses) {
                var responses = responses[0],
                    dialogOptions = { removeOnClose: !0, scrollY: !1, autoFocus: !1 },
                    dialogOptions =
                        (_layoutmanager.default.tv
                            ? (dialogOptions.size = "fullscreen")
                            : (dialogOptions.size = "fullscreen-border"),
                            _dialoghelper.default.createDialog(dialogOptions)),
                    html =
                        ((instance.dlg = dialogOptions).classList.add("formDialog"), ""),
                    responses =
                        ((html += _globalize.default.translateDocument(
                            responses,
                            "sharedcomponents"
                        )),
                            (dialogOptions.innerHTML = html),
                            item.Path
                                ? dialogOptions
                                    .querySelector(".itemPathContainer")
                                    .classList.remove("hide")
                                : dialogOptions
                                    .querySelector(".itemPathContainer")
                                    .classList.add("hide"),
                            (dialogOptions.querySelector(".itemPath").innerHTML =
                                item.Path || ""),
                            dialogOptions
                                .querySelector(".popupIdentifyForm")
                                .addEventListener(
                                    "submit",
                                    instance.onIdentifyFormSubmit.bind(instance)
                                ),
                            dialogOptions
                                .querySelector(".identifyOptionsForm")
                                .addEventListener(
                                    "submit",
                                    instance.onResultConfirmed.bind(instance)
                                ),
                            dialogOptions.classList.add("identifyDialog"),
                            (item.Id
                                ? function (dlg, item) {
                                    var apiClient = _connectionmanager.default.getApiClient(item);
                                    apiClient
                                        .getJSON(
                                            apiClient.getUrl(
                                                "Items/" + item.Id + "/ExternalIdInfos",
                                                { IsSupportedAsIdentifier: !0 }
                                            )
                                        )
                                        .then(function (idList) {
                                            for (
                                                var html = "", i = 0, length = idList.length;
                                                i < length;
                                                i++
                                            ) {
                                                var idInfo = idList[i],
                                                    idLabel =
                                                        ((html += '<div class="inputContainer">'),
                                                            _globalize.default
                                                                .translate("LabelDynamicExternalId")
                                                                .replace("{0}", idInfo.Name));
                                                (html +=
                                                    '<input is="emby-input" class="txtLookupId" data-providerkey="' +
                                                    idInfo.Key +
                                                    '" label="' +
                                                    idLabel +
                                                    '"/>'),
                                                    idInfo.Website &&
                                                    ((html += '<div class="fieldDescription">'),
                                                        _servicelocator.appHost.supports("targetblank") &&
                                                            _servicelocator.appHost.supports("externallinks")
                                                            ? (html +=
                                                                '<a is="emby-linkbutton" class="button-link" href="' +
                                                                idInfo.Website +
                                                                '" target="_blank">' +
                                                                idInfo.Website +
                                                                "</a>")
                                                            : (html += _textencoding.default.htmlEncode(
                                                                idInfo.Website
                                                            )),
                                                        (html += "</div>")),
                                                    (html += "</div>");
                                            }
                                            (dlg.querySelector(".txtLookupName").value = item.FileName || ""),
                                                "Person" === item.Type || "BoxSet" === item.Type
                                                    ? dlg
                                                        .querySelector(".fldLookupYear")
                                                        .classList.add("hide")
                                                    : dlg
                                                        .querySelector(".fldLookupYear")
                                                        .classList.remove("hide"),
                                                (dlg.querySelector(".txtLookupYear").value = ""),
                                                (dlg.querySelector(".identifyProviderIds").innerHTML =
                                                    html),
                                                (dlg.querySelector(".formDialogHeaderTitle").innerHTML =
                                                    _globalize.default.translate("Identify"));
                                        });
                                }
                                : function (dlg, item) {
                                    (dlg.querySelector(".txtLookupName").value = item.Name || ""),
                                        "Person" === item.Type || "BoxSet" === item.Type
                                            ? (dlg
                                                .querySelector(".fldLookupYear")
                                                .classList.add("hide"),
                                                (dlg.querySelector(".txtLookupYear").value = ""))
                                            : (dlg
                                                .querySelector(".fldLookupYear")
                                                .classList.remove("hide"),
                                                (dlg.querySelector(".txtLookupYear").value =
                                                    item.ProductionYear || "")),
                                        (dlg.querySelector(".formDialogHeaderTitle").innerHTML =
                                            _globalize.default.translate("Search"));
                                })(dialogOptions, item),
                            dialogOptions.querySelector(".itemsContainer")),
                    html =
                        ("MusicAlbum" === item.Type &&
                            (responses.classList.remove("vertical-wrap"),
                                responses.classList.add("vertical-list"),
                                dialogOptions
                                    .querySelector(".sectionTitle-cards")
                                    .classList.remove("sectionTitle-cards")),
                            responses.addEventListener(
                                "action-null",
                                function (e) {
                                    var dlg,
                                        e = e.detail.item;
                                    (this.currentSearchResult = e),
                                        _loading.default.hide(),
                                        this.options.item.Id
                                            ? (dlg = this.dlg) && showIdentifyOptions(this, dlg, e)
                                            : ((this.hasChanges = !0), this.closeDialog());
                                }.bind(instance)
                            ),
                            (responses.fetchData = instance.getItems.bind(instance)),
                            (responses.afterRefresh = instance.afterRefresh.bind(instance)),
                            (responses.getListOptions = instance.getListOptions.bind(instance)),
                            (instance.itemsContainer = responses),
                            dialogOptions.addEventListener(
                                "opened",
                                function () {
                                    var itemsContainer = this.itemsContainer;
                                    itemsContainer.resume
                                        ? onItemsContainerUpgraded.call(this)
                                        : _dom.default.addEventListener(
                                            itemsContainer,
                                            "upgraded",
                                            onItemsContainerUpgraded.bind(this),
                                            { once: !0 }
                                        );
                                }.bind(instance)
                            ),
                            function () {
                                _loading.default.hide();
                                var hasChanges = this.hasChanges;
                                return (
                                    this.cleanup(),
                                    hasChanges
                                        ? Promise.resolve(this.currentSearchResult)
                                        : Promise.reject()
                                );
                            }.bind(instance));
                return _dialoghelper.default.open(dialogOptions).then(html, html);
            });
        }),
        (ItemIdentifier.prototype.onIdentifyFormSubmit = function (e) {
            e.preventDefault(), e.stopPropagation();
            (e = this.dlg),
                e &&
                (e.querySelector(".popupIdentifyForm").classList.add("hide"),
                    e
                        .querySelector(".identificationSearchResults")
                        .classList.remove("hide"),
                    e.querySelector(".identifyOptionsForm").classList.add("hide")),
                (e = this.itemsContainer);
            return e && e.refreshItems().then(autoFocus.bind(this)), !1;
        }),
        (ItemIdentifier.prototype.onResultConfirmed = function (e) {
            e.preventDefault(), e.stopPropagation();
            var instance,
                dlg = this.dlg;
            return (
                dlg &&
                (_loading.default.show(),
                    _connectionmanager.default
                        .getApiClient(this.options.item)
                        .applyRemoteSearchResult(
                            (instance = this).options.item.Id,
                            instance.currentSearchResult,
                            {
                                ReplaceAllImages: dlg.querySelector(".chkIdentifyReplaceImages")
                                    .checked,
                            }
                        )
                        .then(
                            function () {
                                var options;
                                (options = _globalize.default.translate(
                                    "RefreshingMetadataDots"
                                )),
                                    Emby.importModule("./modules/toast/toast.js").then(function (
                                        toast
                                    ) {
                                        return toast(options);
                                    }),
                                    (instance.hasChanges = !0),
                                    _loading.default.hide(),
                                    _dialoghelper.default.close(dlg);
                            },
                            function () {
                                _loading.default.hide();
                            }
                        )),
                !1
            );
        }),
        (ItemIdentifier.prototype.closeDialog = function () {
            var dlg = this.dlg;
            dlg && _dialoghelper.default.close(dlg);
        }),
        (ItemIdentifier.prototype.cleanup = function () {
            (this.options = null), (this.dlg = null), (this.itemsContainer = null);
        });
    _exports.default = {
        show: function (item) {
            return new ItemIdentifier({ item: item }).show();
        },
        showFindNew: function (itemName, itemYear, itemType, serverId) {
            return new ItemIdentifier({
                item: {
                    Name: itemName,
                    ProductionYear: itemYear,
                    Type: itemType,
                    ServerId: serverId,
                },
            }).show();
        },
        resetMetadata: function (items) {
            (0, _confirm.default)({
                title: _globalize.default.translate("HeaderRemoveIdentification"),
                text: _globalize.default.translate("ResetMetadataConfirmation"),
                confirmText: _globalize.default.translate("HeaderRemoveIdentification"),
                primaryButton: "cancel",
            }).then(function () {
                var apiClient = _connectionmanager.default.getApiClient(items[0]),
                    options = { ItemIds: items.map(mapToId).join(",") };
                return (
                    _loading.default.show(),
                    apiClient.resetMetadata(options).then(
                        function (result) {
                            return _loading.default.hide(), Promise.resolve(result);
                        },
                        function (err) {
                            return _loading.default.hide(), Promise.reject(err);
                        }
                    )
                );
            });
        },
    };
});
