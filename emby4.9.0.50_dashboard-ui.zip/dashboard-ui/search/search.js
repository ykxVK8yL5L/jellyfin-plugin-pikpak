define([
    "exports",
    "./../modules/emby-elements/emby-scroller/emby-scroller.js",
    "./../modules/viewmanager/baseview.js",
    "./../modules/focusmanager.js",
    "./../modules/emby-apiclient/connectionmanager.js",
    "./searchfields.js",
    "./searchresults.js",
    "./../modules/emby-apiclient/events.js",
], function (
    _exports,
    _embyScroller,
    _baseview,
    _focusmanager,
    _connectionmanager,
    _searchfields,
    _searchresults,
    _events
) {
    function SearchView(view, params) {
        _baseview.default.apply(this, arguments);
        var self = this;
        (self.searchFields = new _searchfields.default({
            serverId:
                params.serverId ||
                _connectionmanager.default.currentApiClient().serverId(),
            element: view.querySelector(".searchFields"),
        })),
            (self.searchResults = new _searchresults.default({
                element: view.querySelector(".searchResults"),
                serverId:
                    params.serverId ||
                    _connectionmanager.default.currentApiClient().serverId(),
                parentId: params.parentId,
                collectionType: params.collectionType,
                requestedItemFields: this.getRequestedItemFields(),
            })),
            _events.default.on(self.searchFields, "search", function (e, value) {
                self.searchResults.search(value);
            });
    }
    Object.defineProperty(_exports, "__esModule", { value: !0 }),
        (_exports.default = void 0),
        Object.assign(SearchView.prototype, _baseview.default.prototype),
        (SearchView.prototype.onPause = function () {
            _baseview.default.prototype.onPause.apply(this, arguments),
                this.searchFields && this.searchFields.pause();
        }),
        (SearchView.prototype.onInputCommand = function (e) {
            "search" === e.detail.command
                ? (_focusmanager.default.focus(
                    this.view.querySelector(".searchfields-txtSearch")
                ),
                    e.preventDefault())
                : _baseview.default.prototype.onInputCommand.apply(this, arguments);
        }),
        (SearchView.prototype.onResume = function (options) {
            _baseview.default.prototype.onResume.apply(this, arguments),
                this.searchFields && this.searchFields.resume(options);
        }),
        (SearchView.prototype.destroy = function () {
            _baseview.default.prototype.destroy.apply(this, arguments),
                this.searchFields &&
                (this.searchFields.destroy(), (this.searchFields = null)),
                this.searchResults &&
                (this.searchResults.destroy(), (this.searchResults = null));
        });
    _exports.default = SearchView;
});
