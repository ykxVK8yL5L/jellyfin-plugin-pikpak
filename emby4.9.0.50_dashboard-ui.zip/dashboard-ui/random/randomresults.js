define([
  "exports",
  "./../modules/emby-elements/emby-scroller/emby-scroller.js",
  "./../modules/emby-elements/emby-button/emby-button.js",
  "./../modules/emby-apiclient/connectionmanager.js",
  "./../modules/common/globalize.js",
  "./../modules/loading/loading.js",
  "./../modules/emby-elements/emby-itemscontainer/emby-itemscontainer.js",
  "./../modules/layoutmanager.js",
  "./../modules/cardbuilder/cardbuilder.js",
  "./../modules/common/itemmanager/itemmanager.js",
  "./../modules/listview/listview.js",
], function (
  _exports,
  _embyScroller,
  _embyButton,
  _connectionmanager,
  _globalize,
  _loading,
  _embyItemscontainer,
  _layoutmanager,
  _cardbuilder,
  _listview,
  _itemmanager
) {
  function getCardOptionsForType(type, items) {
    var options;
    return "BoxSet" === type ||
      "Playlist" === type ||
      "Game" === type ||
      "Book" === type ||
      "PhotoAlbum" === type ||
      "MusicArtist" === type ||
      "Person" === type
      ? {
          shape: "autooverflow",
          fields: ["Name"],
          focusTransformTitleAdjust: !0,
        }
      : "Movie" === type || "Trailer" === type || "Series" === type
      ? {
          shape: "autooverflow",
          fields: ["Name", "ProductionYear"],
          focusTransformTitleAdjust: !0,
        }
      : "Photo" === type
      ? {
          shape: "autooverflow",
          fields: ["Name"],
          focusTransformTitleAdjust: !0,
        }
      : "Audio" === type
      ? {
          shape: "autooverflow",
          preferArtistTitle: !0,
          fields: ["ParentName", "Name"],
          action: "play",
          sideFooter: !0,
          focusTransformTitleAdjust: !0,
        }
      : "TvChannel" === type
      ? {
          shape: "autooverflow",
          fields: ["Name", "CurrentProgramParentName", "CurrentProgramTime"],
          defaultBackground: !0,
          focusTransformTitleAdjust: !0,
        }
      : "Program" === type
      ? ((function (options, type, items) {
          "Program" === type &&
            items.length &&
            items[0].AsSeries &&
            ((options.progress = !1),
            (options.showAirDateTime = !1),
            (options.fields = options.fields
              .filter(isNotName)
              .filter(isNotParentName)
              .filter(isNotAirTime)),
            options.fields.push("ParentNameOrName"));
        })(
          (options = {
            shape: "autooverflow",
            fields: ["ParentName", "Name", "AirTime"],
            showAirDateTime: !0,
            focusTransformTitleAdjust: !0,
          }),
          type,
          items
        ),
        options)
      : "Tag" === type
      ? {
          shape: "autooverflow",
          fields: ["Name"],
          defaultBackground: !0,
          multiSelect: !1,
          focusTransformTitleAdjust: !0,
        }
      : {
          shape: "autooverflow",
          fields: ["ParentName", "Name"],
          focusTransformTitleAdjust: !0,
        };
  }
  function isNotName(n) {
    return "Name" !== n;
  }
  function isNotParentName(n) {
    return "ParentName" !== n;
  }
  function isNotAirTime(n) {
    return "AirTime" !== n;
  }
  function getSearchFields(instance, type) {
    instance =
      instance.options.requestedItemFields +
      ",PrimaryImageAspectRatio,ProductionYear";
    return (
      (type && "Series" !== type) || (instance += ",Status,EndDate"), instance
    );
  }
  function populateResults(result, context, section, cardOptions) {
    (result = result.Items || result.SearchHints),
      (context = (section =
        "string" == typeof section
          ? context.querySelector(section)
          : section).querySelector(".itemsContainer"));
    return (
      // _listview.default.buildItems(result, Object.assign({
      //         image: !1,
      //         fields: ["MediaStreamInfo"],
      //         itemsContainer: context,
      //         action: "none",
      //         multiSelect: !1,
      //         ratingButton: !1,
      //         playedButton: !1,
      //         defaultIcon: !1,
      //         typeIndicator: !1,
      //         playedIndicator: !1,
      //         syncIndicator: !1,
      //         downloadButton: !1,
      //         timerIndicator: !1,
      //         randomDefaultBackground: !1,
      //         imageFallback: !1,
      //         innerCardFooterClass: "mediaStreamInnerCardFooter",
      //         enableUserDataButtons: !1,
      //         draggable: !1,
      //       })),
      _cardbuilder.default.buildCards(
        result,
        Object.assign(
          {
            itemsContainer: context,
            parentContainer: section,
            shape: "autooverflow",
            scalable: !0,
            focusTransformTitleAdjust: !0,
            horizontal: !1,
          },
          cardOptions || {}
        )
      ),
      section
        .querySelector(".emby-scroller")
        .scrollToBeginning({ behavior: "instant" }),
      result
    );
  }
  function RandomResults(options) {
    var elem, instance;
    (this.options = options),
      (elem = options.element),
      (instance = this),
      elem.classList.add("randomResults"),
      instance.search("");
  }
  Object.defineProperty(_exports, "__esModule", { value: !0 }),
    (_exports.default = void 0),
    (RandomResults.prototype.search = function (value) {
      _loading.default.show();
      var apiClient = _connectionmanager.default.getApiClient(
          this.options.serverId
        ),
        elem = this.options.element;
      searchInfo =
        (elem.querySelector(".noResults").classList.add("hide"),
        { instance: this, searchTerm: value });
      return (function (instance, apiClient, context, value) {
        value || _layoutmanager.default.tv;
        var query = {
          EnableImages: !0,
          SortBy: "Random",
          EnableTotalRecordCount: !1,
          Recursive: !0,
          Fields:
            this.requestedItemFields +
            ",PrimaryImageAspectRatio,ProductionYear",
          ImageTypeLimit: 1,
          MediaTypes: "Video",
          Limit: 36,
        };
        return apiClient
          .getItems(apiClient.getCurrentUserId(), query)
          .then(function (result) {
            var subPromises = [];
            return (
              subPromises.push(
                populateResults(
                  result,
                  context,
                  context.querySelector(".globalResults"),
                  {
                    shape: "autooverflow",
                    fields: [
                      "ParentName",
                      "Name",
                      "Type",
                      "CurrentProgramParentName",
                      "AirTime",
                    ],
                    showAirDateTime: !0,
                    lines: 4,
                  }
                )
              ),
              Promise.all(subPromises)
            );
          });
      })(this, apiClient, elem, value).then(
        function (itemsResponses) {
          _loading.default.hide();
          var hasResults,
            i,
            length,
            options = this.instance.options;
          if (options) {
            if (itemsResponses[0].length && (hasResults = !0))
              for (i = 0, length = itemsResponses.length; i < length; i++)
                if (itemsResponses[i].length) {
                  hasResults = !0;
                  break;
                }
            options = options.element.querySelector(".noResults");
            hasResults || !this.searchTerm
              ? options.classList.add("hide")
              : (this.searchTerm.length < 1
                  ? (options.innerHTML = _globalize.default.translate(
                      "TwoSearchCharsRequired"
                    ))
                  : (options.innerHTML = _globalize.default.translate(
                      "NoItemsMatchingFound"
                    )),
                options.classList.remove("hide"));
          }
        }.bind(searchInfo),
        function () {
          _loading.default.hide();
          var options = this.options;
          options &&
            options.element
              .querySelector(".noResults")
              .classList.add("hide");
        }.bind(this)
      );
    }),
    (RandomResults.prototype.destroy = function () {
      var options = this.options;
      options && options.element.classList.remove("randomResults"),
        (this.options = null);
    });
  _exports.default = RandomResults;
});
