define([
    "exports",
    "./../modules/emby-elements/emby-scroller/emby-scroller.js",
    "./../modules/viewmanager/baseview.js",
    "./../modules/focusmanager.js",
    "./../modules/emby-apiclient/connectionmanager.js",
    "./randomresults.js",
    "./../modules/emby-apiclient/events.js",
], function (
    _exports,
    _embyScroller,
    _baseview,
    _focusmanager,
    _connectionmanager,
    _randomresults,
    _events
) {
    function RandomView(view, params) {
        _baseview.default.apply(this, arguments);
        var self = this;
            (self.randomresults = new _randomresults.default({
                element: view.querySelector(".randomResults"),
                serverId:
                    params.serverId ||
                    _connectionmanager.default.currentApiClient().serverId(),
                parentId: params.parentId,
                collectionType: params.collectionType,
                requestedItemFields: this.getRequestedItemFields(),
            }))
            //self.randomresults.search("")
    }
    Object.defineProperty(_exports, "__esModule", { value: !0 }),
        (_exports.default = void 0),
        Object.assign(RandomView.prototype, _baseview.default.prototype),
        (RandomView.prototype.onPause = function () {
            _baseview.default.prototype.onPause.apply(this, arguments);
        }),
        (RandomView.prototype.onInputCommand = function (e) {
            _baseview.default.prototype.onInputCommand.apply(this, arguments);
        }),
        (RandomView.prototype.onResume = function (options) {
            _baseview.default.prototype.onResume.apply(this, arguments);
        }),
        (RandomView.prototype.destroy = function () {
            _baseview.default.prototype.destroy.apply(this, arguments),
            (this.randomresults.destroy(), (this.randomresults = null));
        });
    _exports.default = RandomView;
});
